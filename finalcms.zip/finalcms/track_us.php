<?php
session_start();
error_reporting(0);
include "admin/config.php";
include "header.php";


?>
<style>
    .itm-address b {
    display: block;
    border-bottom: 2px solid #fab232;
    margin-bottom: 12px;
    padding-bottom: 3px;
    display: block;
    width: 25px;
}
    .tcontner:nth-child(1) {
    padding-left: 11%;
    padding-top: 3%;
    float:left;
    width: 31%;
}
.address-cont h3 {
    font-weight: bold;
    color: #000;
    margin-bottom: 5px;
}
.tcontner:nth-child(2) {
    width: 32%;
    float:left;
}
.tcontner:nth-child(3) {
    width: 30%;
    float:right;
}
.demo-popup-box {
    border: 1px solid rgba(60%,60%,60%,0.5);
    z-index: 0;
    position: absolute;
    left: 0;
    right: 0;
    max-width: 440px;
    margin: auto;
    top: 41%;
    background: #fff;
    padding: 30px;
    border-radius: 0;
    padding: 30px 50px;
    text-align: center;
}


form {
    display: inline-block;
    width: 100%;
}
.demo-popup-box h3 {
    color: #fab232;
    text-align: center;
    text-transform: uppercase;
    margin: 10px 0 20px 0;
    font-size: 40px;
    font-family: sans-serif;
    font-weight: bold;
}
.demo-popup-box .form-control {
    background: #ddd0;
    color: #000;
    margin: 10px 0;
    border: none;
    border-bottom: 1px solid #fab232;
    box-shadow: none;
    border-radiufab232s: 0;
    padding: 5px 0px;
    margin: 25px 0;
    line-height: 8px;
}
.demo-popup-box .btn-submit:hover {
    background-image: -webkit-linear-gradient( 180deg, rgb(253, 186, 55) 0%, rgb(255, 184, 109) 100%);
    background-image: -ms-linear-gradient( 180deg, rgb(253, 186, 55) 0%, rgb(248, 154, 54) 100%);
}
.demo-popup-box .btn-submit {
    color: #fff;
    transition: all ease 0.5s;
    text-transform: uppercase;
    height: 55px;
    width: 169px;
    margin: 30px 0 50px 0;
    font-size: 19px;
    border-radius: 50px;
    background-image: -moz-linear-gradient( 180deg, rgb(253, 186, 55) 0%, rgb(248, 154, 54) 100%);
    background-image: -webkit-linear-gradient( 180deg, rgb(253, 186, 55) 0%, rgb(248, 154, 54) 100%);
    background-image: -ms-linear-gradient( 180deg, rgb(253, 186, 55) 0%, rgb(248, 154, 54) 100%);
    border: none;
    cursor: pointer;
}
.address-cont {
  
    padding-top: 20px;
}
.tcontner:nth-child(3) .itm-address {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 15px;
}
.itm-address {
    padding-right: 15px;
    color: #000;
    font-size: 14px;
}
.tcontner:nth-child(3) .itm-address > div:nth-child(1) {
    padding-right: 20px;
    margin-bottom: 15px;
}
.tcontner:nth-child(3) .itm-address > div {
    flex: 1 50%;
}
</style>


 

<div class="w-100">
    <?php
session_start();
error_reporting(0);
include "config.php";
if(isset($_POST['save'])) { 
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading) VALUES ('$imagename', '$PageDes', '$Heading')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>
<section id="sec-5">

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.91336118917!2d77.14016740464616!3d28.63235863581304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d032309de0ebf%3A0x4fb35a791a3682f0!2sITG+Telematics+Pvt.+Ltd.!5e0!3m2!1sen!2sin!4v1528020954166" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen=""></iframe> 




 </section>
 <section style="border-top: solid 5px #fab232;">
 <div class="map-text-content">

<div class="tcontner">

    <div class="address-cont">

        <div class="itm-address">

            <h3>HEAD OFFICE</h3>

            <p><b>Delhi</b> B-100 2nd floor Neelkanth Building, <br> Naraina Industrial Area Phase-1, New Delhi-110028<br></p>

        </div>

        <div class="itm-address">

           <!--  <h4>PHONE</h4> -->

            <p>

                + 91 11-4625-4625/4915-5050 

            </p>

        </div>

        <div class="itm-address">

           <!--  <h4>MAIL</h4> -->

            <span>

               info@g-trac.in

                </span>

        </div>

    </div>

</div>

<div class="tcontner">
  

    <form method="post" action="" autocomplete="off">

    <div class="demo-popup-box">

        <h3>Track Us</h3>
<input placeholder="Your name" class="form-control" name="name" type="text" tabindex="1" autofocus="">
<input placeholder="Your Email Address" class="form-control" name="email" type="email" tabindex="2">
<input placeholder="Your Phone Number" class="form-control" name="tel" type="tel" tabindex="3">

<textarea name="message" class="form-control" placeholder="Type your Message Details Here..." tabindex="5"></textarea>

<button type="submit" name="submit" class="btn-submit" id="contact-submit" data-submit="...Sending">Submit Now</button>

        

    </div>

    </form>

</div>

<div class="tcontner">

    <div class="address-cont">

        <h3>BRANCH</h3>

        <div class="itm-address">

            <div>

                

                <p><b>Ahmedabad</b> D/504, Signature 2,  Near Sarkhej-Sanand Circle, SG Highway, Ahmedabad - 382210 </p>

                <p>+ 91 9687666815</p>                            

            </div>

            <div>

                <p><b>Jaipur</b> 410, Luhadia Tower, Ahinsa Circle, <br>C-Scheme, Jaipur - 302001</p>

                <p>+91 141-405-4626</p>                            

            </div>

            <div>

                <p><b>Mumbai</b> 906 A, Real Tech Park, Near Inorbit Mall, Sector - 30, Vashi, Navi Mumbai - 400703 </p>

                <p>+ 91 11-4915-5020/21</p>                            

            </div>

            <div>

                <p><b>Kolkata</b>ITG Telematics Pvt Ltd 6, N.S Road, Annex Building, 2nd Floor Bengal Chamber of Commerce &amp; Industry, Kolkata - 700001 </p>

                <p>+91 9674875773 / 7604070170</p>

            </div>

        </div>

        </div>

    </div>

</div>
 </section>
</div>
    
      <?php
     include "footer.php";
      ?>






