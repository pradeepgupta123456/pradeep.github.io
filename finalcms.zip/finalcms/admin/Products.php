<?php
session_start();
error_reporting(0);
include "config.php";
include "header.php";

if(isset($_POST['save'])) { // if save button on the form is clicked
  $imgid=intval($_GET['imageid']);
echo $imgid;
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  $pradeep = $_SESSION["abc"];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading, pagename) VALUES ('$imagename', '$PageDes', '$Heading', '$pradeep')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>

<style> 
.headclass:nth-child(4) {
  display:none;
}
.headclass:nth-child(8) {
    margin-top: 50px;
    float: left;
    font-size: 10px;
    width: 50%;
}
.headclass:nth-child(8) h1 {
    font-size: 40px;
    font-weight: 500;
    margin-bottom: 20px;
}

.headclass:nth-child(12) {
    display:none;
}
.headclass:nth-child(16) {
    display:none;
}
.headclass:nth-child(20) {
    display:none;
}
.headclass:nth-child(24) {
    display:none;
}
.headclass:nth-child(28) {
    display:none;
}
.headclass:nth-child(32) {
    display:none;
}
.headclass:nth-child(36) {
    display:none;
}
.headclass:nth-child(40) {
    display:none;
}
.headclass:nth-child(44) {
    display:none;
}
.headclass:nth-child(48) {
    display:none;
}
.productsheading{
  position:absolute;
  font-size: 56px;
    font-weight: bold;
    text-align: center;
    margin-top: 71px;
    z-index: 8;
    width: 100%;
  
}
.bold-text {
    font-weight: 600;
}
.spe_list {
    display: flex;
    flex-wrap: wrap;
    margin: 22px 0;
}
.margineand {
    flex: 1 50%;
    margin-bottom: 15px;
    border-bottom: 1px solid #fbfafa;
    padding-bottom: 5px;
}
section {
    display: block;
}
.por-header {
    background: #eae8e8;
    padding: 15px;
    text-align: left;
    color: #000;
    font-weight: bold;
    width: 100%;
    margin-bottom: 40px;
    font-size: 25px;
    border-radius: 5px;
}


.descritiopnclassproduct:nth-child(5) {
  position: absolute;
    margin-top: -252px;
    margin-left: 10%;
    font-size: 1.5vw;
    font-weight: 600;
}
.hedimg:nth-child(7) {
  width: 50%;
    float: left;
    padding: 20px 80px;
}
.descritiopnclassproduct:nth-child(7) {
  width: 50%;
    float: left;
    padding: 49px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
}
.hedimg:nth-child(11) {
 display:none
}
.descritiopnclassproduct:nth-child(10) {
  width: 100%;
    float: left;
    padding: 68px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
    background-color: rgba(0, 0, 0, 0.56);
    color:#fff;
    font-size:22px;
    text-align:center;
}
.descritiopnclassproduct:nth-child(10):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.hedimg:nth-child(12) {
 display:none
}
.descritiopnclassproduct:nth-child(13) {
 background: #eae8e8;
    padding: 15px;
    text-align: left;
    color: #000;
    font-weight: bold;
    width: 91%;
    font-size: 25px;
    border-radius: 5px;
    float: left;
    margin-left: 62px;
}


.descritiopnclassproduct:nth-child(17) {
  float: left;
    margin-top: 36px;
    width: 18%;
}
.descritiopnclassproduct:nth-child(16):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.hedimg:nth-child(15) {
  float: left;
    margin-left: 63px;
    margin-top: 17px;
}
.hedimg:nth-child(19) {
  float: left;
    margin-top: 17px;
    width:80px;
}
.hedimg:nth-child(23) {
    float: left;
    margin-top: 17px;
    margin-left: 30px;
}
.hedimg:nth-child(27) {
  float: left;
    margin-left: 61px;
}
.hedimg:nth-child(31) {
  width:82px;
  float:left;
}
.hedimg:nth-child(35) {
  width:80px;
  float:left;
}
.hedimg:nth-child(39) {
  width: 66px;
    float: left;
    margin-left: 61px;
}
.hedimg:nth-child(43) {
  width:100px;
  float:left;
  margin-top: 5px;
}
.hedimg:nth-child(47) {
  width:100px;
  float:left;
  margin-top: 12px;
}


.descritiopnclassproduct:nth-child(21) {
    width: 19%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(25) {
  width: 17%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
    margin-left: 15px;
}
.descritiopnclassproduct:nth-child(29) {
  width: 20%;
    float: left;
    padding: 16px 6px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(33) {
    width: 19%;
    float: left;
    padding: 15px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(37) {
width: 17.3%;
    float: left;
    padding: 16px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(41) {
width: 20%;
    float: left;
    padding: 16px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(45) {
width: 17.7%;
    float: left;
    padding: 21px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(49) {
width: 15%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}



.descritiopnclassproduct:nth-child(19):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.Updatedutton:nth-child(6) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: 133px;
    right: 0px;
}
.Updatedutton:nth-child(18) {
 width: 9%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: left;
    margin-left: 2%;
   
    float: left;
    margin-top: 32px;
}
.Updatedutton:nth-child(22) {
 width: 5%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
}
.Updatedutton:nth-child(26) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(30) {
 width: 8.9%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 15px;
    height: 100PX;
}
.Updatedutton:nth-child(34) {
 width: 7%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 14px;
    height: 100PX;
}
.Updatedutton:nth-child(38) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 15px;
    height: 100PX;
}
.Updatedutton:nth-child(42) {
  width: 8.7%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 18px;
    height: 100PX;
}
.Updatedutton:nth-child(46) {
 width: 7.5%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(50) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}


.Updatedutton:nth-child(11) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -548px;
    right: 0px;
}
.Updatedutton:nth-child(14) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -367px;
    right: 0px;
}
.Updatedutton:nth-child(17) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -871px;
    right: 0px;
}
.Updatedutton:nth-child(20) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -1026px;
    right: 0px;
}
</style>
 <div class="solution">

 
  <form class="form-horizontal " name="insertproduct" method="post" enctype="multipart/form-data">
    
    

    <div class="control-group"> 
    <button id="hide" class="float-right">Hide</button>
      <label class="control-label" for="basicinput">Upload Image</label>
      <div class="controls">
        <input type="file" name="imagename" id="imagename" value="" class="span8 tip" required>
      </div>
      <textarea class="headingname" name="allheading" placeholder="heading"></textarea>
      <textarea id="edit" name="firstpage" placeholder="Description"></textarea>
      <div class="col-md-6">
       
        <a class="pagename "><?php
     
      if(isset($_POST['submit1'])) {
    
        $pradeep = $_POST['submit1'];
       
       echo "$pradeep";
       
       $_SESSION["abc"] = $pradeep;
    
      }
      ?> </a>
  
              
    </div>
    </div>
    <div class="form-group row pt-3">
      <div class="col-12">
        <button type="submit" class="btn btn-success" name="save">
          <i class="fa fa-plus "></i> Upload
        </button>
      </div>
    </div>
  </form>

  <a class="productsheading"><?php
     
     if(isset($_POST['submit1'])) {
   
       $pradeep = $_POST['submit1'];
      
      echo "$pradeep";
      
      $_SESSION["abc"] = $pradeep;
   
     }
     ?> </a>

      <?php 
     
     
     $sql = "SELECT * from imageupload where pagename='$pradeep' LIMIT 12";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
       
 
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
            </div>
            <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
            <div class="descritiopnclassproduct"><?php echo ($result->pdescription) ?> </div>
            <div class="Updatedutton">
              <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn "><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        </div>
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <section id="specificationdiv">

		

<div class="container p-0">

        

  <div class="spe_list">

            <h1 class="por-header">Specification</h1>
            <div class="row">
       <div class="col-sm-6 margineand"><span class="bold-text">GSM frequency</span></div>

       <div class="col-sm-6 margineand">850/900/1800/1900 MHz</div>  

       

       <div class="col-sm-6 margineand"><span class="bold-text">GPRS</span></div>

       <div class="col-sm-6 margineand">Class 12, TCP/IP</div>

       

         <div class="col-sm-6 margineand"><span class="bold-text">Memory</span></div>

       <div class="col-sm-6 margineand">32Mb/64Mb</div>

       

       <div class="col-sm-6 margineand"><span class="bold-text">GPS chipset</span></div>

       <div class="col-sm-6 margineand">MTK high sensitivity chip</div>

       

       <div class="col-sm-6 margineand"><span class="bold-text">GPS channel</span></div>

       <div class="col-sm-6 margineand">66</div>

       

       <div class="col-sm-6 margineand"><span class="bold-text">Location accuracy</span></div>

       <div class="col-sm-6 margineand">&lt;10 meters</div>

       

       <div class="col-sm-6 margineand"><span class="bold-text">Tracking sensitivity</span></div>

       <div class="col-sm-6 margineand">-165dBm/-162dBm</div>

       

       <div class="col-sm-6 margineand"><span class="bold-text">Acquisition sensitivity</span></div>

       <div class="col-sm-6 margineand">-148dBm</div>

       

       <div class="col-sm-6 margineand"><span class="bold-text">TTFF (open sky)</span></div>

       <div class="col-sm-6 margineand">Avg. hot start ≤2sec Avg. cold start ≤35sec</div>

      

       <div class="col-sm-6 margineand"><span class="bold-text">Voice monitor range</span></div>

       <div class="col-sm-6 margineand">≤5 meters</div>

       

       <div class="col-sm-6 margineand"><span class="bold-text">Working voltage/current</span></div>

       <div class="col-sm-6 margineand">9-36VDC/45mA(12VDC), 28mA(24VDC)</div>

       

       <div class="col-sm-6 margineand"><span class="bold-text">Operating temperature</span></div>

       <div class="col-sm-6 margineand">-20℃～ 70℃</div>

       

       

  </div></div>

</div>

</section>
   
       
</div> 


    
      <?php
     include "footer.php";
      ?>






