
<!DOCTYPE HTML>
<html lang="en">
<head>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <title>Gtrac</title>
 <!--Bootstrap -->


 
 <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
 <link rel="stylesheet" href="css/frontend.min.css" type="text/css">
 <link rel="stylesheet" href="css/style(5).css" type="text/css">
 <link rel="stylesheet" href="css/mainadmin.css" type="text/css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script src="https://code.jquery.com/jquery-3.6.3.js"></script>
 <link href="css/thumbnail-slider.css" rel="stylesheet" type="text/css">
    <script src="js/thumbnail-slider.js.download" type="text/javascript"></script>
    
 <script>
$(document).ready(function(){
  $("#hide").click(function(){
    $(".form-horizontal").hide();
  });
  $("#show").click(function(){
    $("p").show();
  });

});
</script>
<script src="js/jquery.slim.min.js.download"></script>
  
    <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
</head>
<body>
<?php
	if (isset($_POST['logout']))
		{
		
					header('location:index.php');
		
		}
  ?>
<div class="topheader">
  <div class="container-fluid">
  <form name="insertproduct" method="post" class="headerform">

        <div class="row">
            <div class="col-md-4">
            <i class="fa fa-envelope-o pr-1" aria-hidden="true" style="color:#468e82;font-weight: bold;"></i>  info@g-trac.in
            </div>
              <div class="col-md-8 text-right p-0">
              <button type="submit" name="logout" class="logout"><i class="fa fa-sign-out" aria-hidden="true"></i></button>  

              <div class="lockbuttonmain">

              <a class="addbutton1" href="https://gtrac.in/newtracking/reports/load_search_data_with_reports.php?action=search_with_reports" target="_blank"><i class="fa fa-lock mr-2" aria-hidden="true"></i>Lock</a></div>
              <div class="headermobileno"><i class="fa fa-phone pr-1 " aria-hidden="true"></i>011 - 46254625 </div>
            </div>

       </div>
       </form>
  </div>
</div>

<nav class="navbar navbar-expand-sm   navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
       <img src="media/logo.png" class="logostyle" />
         
          <div class="social-part">
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          <?php
                            $sql = " SELECT * FROM menu where menuid='1'";

                            $result = $conn->query($sql);
                             while($rows=$result->fetch_assoc())
                                {
                            ?>
                                      
                                        <?php 
                            foreach ($result as $rows) {
                            ?>
            <li class="nav-item">
              <a class="nav-link" href="home.php"> <span class="sr-only">(current)</span>
              <form method="post" action="home.php">
                                        <input type="submit" value="<?php echo $rows['menuname'];?>" name="submit1" class="submenubutton" />
                                        </form>
              </a>
            </li>
            <?php
                                    }
                            
                                    }
                            
                                ?>
           
            <?php
                            $sql = " SELECT * FROM menu where menuid='2'";

                            $result = $conn->query($sql);
                             while($rows=$result->fetch_assoc())
                                {
                            ?>
                                      
                                        <?php 
                            foreach ($result as $rows) {
                            ?>
            <li class="nav-item">
              <a class="nav-link" href="aboutus.php">
              <form method="post" action="aboutus.php">
                                        <input type="submit" value="<?php echo $rows['menuname'];?>" name="submit1" class="submenubutton" />
                                        </form>
              </a>
            </li>
            <?php
                                    }
                            
                                    }
                            
                                ?>
          
            <li class="nav-item dropdown dmenu">
            <a class="nav-link dropdown-toggle" href="Solutions.php" id="navbardrop" data-toggle="dropdown">
            SOLUTIONS
            </a>
            <div class="dropdown-menu sm-menu">
              <a class="dropdown-item" href="#">
              <form method="post" action="Solutions.php">
              <?php
                                                    $sql = " SELECT * FROM submenu where menuid='3'";

                                                    $result = $conn->query($sql);
                                                        while($rows=$result->fetch_assoc())
                                                        {
                                                    ?>
                                                                            
                                                                                <?php 
                                        foreach ($result as $rows) {
                                        ?>
                                        <input type="submit" value="<?php echo $rows['submenu'];?>" name="submit1" class="submenubutton" />
                                        <?php
                                            }
                                    
                                            }
                                    
                                        ?> 
                                      </form>  
              </a>
           

              
            </div>
          </li>
        
         
          <li class="nav-item dropdown dmenu">
            <a class="nav-link dropdown-toggle" href="Benefits.php" id="navbardrop" data-toggle="dropdown">
            BENEFITS
            </a>
            <div class="dropdown-menu sm-menu">
              <a class="dropdown-item" href="#">
              <form method="post" action="Benefits.php">
              <?php
                                                    $sql = " SELECT * FROM submenu where menuid='4'";

                                                    $result = $conn->query($sql);
                                                        while($rows=$result->fetch_assoc())
                                                        {
                                                    ?>
                                                                            
                                                                                <?php 
                                        foreach ($result as $rows) {
                                        ?>
                                        <input type="submit" value="<?php echo $rows['submenu'];?>" name="submit1" class="submenubutton" />
                                        <?php
                                            }
                                    
                                            }
                                    
                                        ?> 
                                      </form>  
              </a>
           
            </div>
          </li>
       
          <li class="nav-item dropdown dmenu">
            <a class="nav-link dropdown-toggle" href="Products.php" id="navbardrop" data-toggle="dropdown">
            PRODUCTS
            </a>
            <div class="dropdown-menu sm-menu">
              <a class="dropdown-item" href="#">
              <form method="post" action="Products.php">
                
              <?php
                                                    $sql = " SELECT * FROM submenu where menuid='5'";

                                                    $result = $conn->query($sql);
                                                        while($rows=$result->fetch_assoc())
                                                        {
                                                    ?>
                                                                            
                                                                                <?php 
                                        foreach ($result as $rows) {
                                        ?>
                                        <input type="submit" value="<?php echo $rows['submenu'];?>" name="submit1" class="submenubutton" />
                                        <?php
                                            }
                                    
                                            }
                                    
                                        ?>  
                                      </form>  
              </a>
              
            </div>
          </li>
          <?php
                            $sql = " SELECT * FROM menu where menuid='6'";

                            $result = $conn->query($sql);
                             while($rows=$result->fetch_assoc())
                                {
                            ?>
                                      
                                        <?php 
                            foreach ($result as $rows) {
                            ?>
            <li class="nav-item">
              <a class="nav-link" href="customer.php"> <span class="sr-only">(current)</span>
              <form method="post" action="customer.php">
                                        <input type="submit" value="<?php echo $rows['menuname'];?>" name="submit1" class="submenubutton" />
                                        </form>
              </a>
            </li>
            <?php
                                    }
                            
                                    }
                            
                                ?>
        
         
         
          
          </ul>
          </div>
          <a href="track_us.php"><div class="addbutton">TRACK US</div></a>
        </div>
      </nav>
      <div id="mySidenav" class="mymenusidebar">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="adminsubmenu.php">Create Submenu</a>
 
 
</div>

<span class="leftmenubaradmin" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script type="text/javascript">
$(document).ready(function () {
$('.navbar-light .dmenu').hover(function () {
        $(this).find('.sm-menu').first().stop(true, true).slideDown(150);
    }, function () {
        $(this).find('.sm-menu').first().stop(true, true).slideUp(105)
    });
});
</script>
