<?php
session_start();
error_reporting(0);
include "config.php";
include "header.php";

if(isset($_POST['save'])) { // if save button on the form is clicked
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  $pradeep = $_SESSION["abc"];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading, pagename) VALUES ('$imagename', '$PageDes', '$Heading', '$pradeep')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>
<style>
  .form-horizontal {
    display:none;
  }
  .aboutusfirstbutton{
    position: absolute;
    bottom: 161px;
    right: 0;
  }
</style>

 <div class="aboutusmain">

 
  <form class="form-horizontal " name="insertproduct" method="post" enctype="multipart/form-data">
    
    

    <div class="control-group"> 

<button id="hide" class="float-right">Hide</button>
      <label class="control-label" for="basicinput">Upload Image</label>
      <div class="controls">
        <input type="file" name="imagename" id="imagename" value="" class="span8 tip" required>
      </div>    
      <textarea class="headingname" name="allheading" placeholder="head text here"></textarea>
      <textarea id="edit" name="firstpage" placeholder="Desc text here"></textarea>
      <div class="col-md-6">
       
        <a class="pagename"><?php
     
      if(isset($_POST['submit1'])) {
    
        $pradeep = $_POST['submit1'];
       
       echo "$pradeep";
       
       $_SESSION["abc"] = $pradeep;
    
      }
      ?> </a>
  
              
    </div>
    </div>
    <div class="form-group row pt-3">
      <div class="col-12">
        <button type="submit" class="btn btn-success" name="save">
          <i class="fa fa-plus "></i> Upload
        </button>
      </div>
    </div>
  </form>

  

      <?php 
      $sql = "SELECT * from imageupload where pagename='$pradeep' and id='65'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
            <div class="positionabsolutefirst"><?php echo ($result->pdescription) ?> </div>
            <div class="Updatedutton aboutusfirstbutton">
              <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn text-white"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        </div>
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
      $sql = "SELECT * from imageupload where pagename='$pradeep' and id='66'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
        <div class="container mt-5">
        <div class="row">
        <div class="col-md-6" style="padding: 15px 74px;">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-md-6">
            <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
            <div class="descritiopnclasssecond" ><?php echo ($result->pdescription) ?> </div>
       
            <div class="Updatedutton text-right" style="margin-right: -119px;">
              <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn" style="color:#03700c"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        </div>
        </div>
        </div>
        </div>
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
      $sql = "SELECT * from imageupload where pagename='$pradeep' and id='67'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        <div class="firstbackgroundcolor mt-5">
        <div class="container mt-5">
        <div class="row">
        <!-- <div class="col-md-6">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div> -->
            <div class="col-md-12">
            <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
            <div class="WHYGTRAC"><?php echo ($result->pdescription) ?> </div>
       
            <div class="Updatedutton text-right" style="margin-right: -119px;">
              <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn text-white"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        </div>
        </div>
        </div>
        </div>
        </div>
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <div class="container-fluid">
      <div class="row">
      <?php 
      $sql = "SELECT * from imageupload where pagename='$pradeep' and id='73'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="col-4 ornge">
               <div class="text-center onlyheightfirst">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
                    <div class="headclass"><h6><?php echo ($result->heading) ?></h6> </div>
                    <div class="descritiopnclassforrbr text-center"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right">
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn text-white"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
     $sql = "SELECT * from imageupload where pagename='$pradeep' and id='74'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="col-4 blue">
               <div class="text-center onlyheightfirst">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
                    <div class="headclass"><h6><?php echo ($result->heading) ?></h6> </div>
                    <div class="descritiopnclassforrbr"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right">
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn text-white"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
     $sql = "SELECT * from imageupload where pagename='$pradeep' and id='75'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="col-4 red">
               <div class="text-center onlyheightfirst">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
                    <div class="headclass"><h6><?php echo ($result->heading) ?></h6> </div>
                    <div class="descritiopnclassforrbr"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn text-white"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>



   </div>
</div> 
</div> 
<section>
  <div class="container mt-5">
<?php 
      $sql = "SELECT * from imageupload where pagename='$pradeep' and id='76'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
      $sql = "SELECT * from imageupload where pagename='$pradeep' and id='77'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <?php 
      $sql = "SELECT * from imageupload where pagename='$pradeep' and id='78'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <?php 
     $sql = "SELECT * from imageupload where pagename='$pradeep' and id='79'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <?php 
     $sql = "SELECT * from imageupload where pagename='$pradeep' and id='80'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <?php 
      $sql = "SELECT * from imageupload where id='29'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      </div>
</section>
<section>

         <div class="container">

            <div class="row">

               <div class="col-lg-1 timeline_circle ">

                  <h3>2010</h3>

                  <h6>January</h6>

                  <p>ITG Telematics Pvt.Ltd</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2010</h5>

                  <h6>November</h6>

                  <img src="media/tl_10.png" class="img-fluid">

                  <h6>1000 Subscribers</h6>

                  <p>Tested the waters and ready to swim.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2011</h5>

                  <h6>January</h6>

                  <img src="media/tl_11.png" class="img-fluid">

                  <h6>Repair Centre</h6>

                  <p>In-house repair team to expedite service standards.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2011</h5>

                  <h6>March</h6>

                  <img src="media/tl_11a.png" class="img-fluid">

                  <h6>Mobile Apps</h6>

                  <p>To meet the demand for "reports on the go" </p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2012</h5>

                  <h6>May</h6>

                  <img src="media/tl_11b.png" class="img-fluid">

                  <h6>Let's Explore</h6>

                  <p>Jaipur branch started as the first expansion initiative</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2013</h5>

                  <h6>February</h6>

                  <img src="media/tl_12.png" class="img-fluid">

                  <h6>Big Clients</h6>

                  <p>Maruti and Lubrizol on board for supply-chain management.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2014</h5>

                  <h6>March</h6>

                  <img src="media/tl_12a.png" class="img-fluid">

                  <h6>More Branches</h6>

                  <p>More branches and service centers started.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2014</h5>

                  <h6>February</h6>

                  <img src="media/tl_13.png" class="img-fluid">

                  <h6>Short code</h6>

                  <p>Tested the waters and ready to swim.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2015</h5>

                  <h6>March</h6>

                  <img src="media/tl_13a.png" class="img-fluid">

                  <h6>DIMTS</h6>

                  <p>Empanelment with Dept. of Telecom,(DOT) / Transport.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2016</h5>

                  <h6>November</h6>

                  <img src="media/tl_13b.png" class="img-fluid">

                  <h6>Kanpur Police</h6>

                  <p>Control center for PCR vehicles tracking.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2017</h5>

                  <h6>july</h6>

                  <img src="media/tl_14.png" class="img-fluid">

                  <h6>PSUs added</h6>

                  <p>Company has added more than 15 PSU clients in 2014 and added Big Clients like Aggarwal Movers</p>

               </div>

               <div class="col-lg-1 ico_edit">

                  <h5>2018</h5>

                  <h6>March</h6>

                  <img src="media/tl_15.png" class="img-fluid">

                  <h6>Reliance Jio</h6>

                  <p>Recieved an order for 300 subscribers, potential is 2000 subscribers.</p>

               </div>

            </div>

         </div>

      </section>
      <section class="bg_blue text-center py-5">

         <div class="container-fluid py-5">

            <div class="row white-text">

               <div class="col-lg-12">

                  <img src="img/photo.png" class="img-fluid companyMd" alt="placeholder">

                  <div class="gt"><img src="img/gt.png" alt=""> </div>

                  <div class="gtt"><img src="img/team.png" alt=""></div>

                  <h2>Mr. Anuj Juneja</h2>

                  <h5 class="mb-0">FOUNDER</h5>

                  <hr class="white accent-2 mt-0 d-inline-block mx-auto" style="width: 60px;">

                  <h5 class="mb-5">Mr. Anuj Juneja, Founder, ITG Telematics Pvt. Ltd. is actively leading all efforts in <br> establishing ITG's PAN India corporate sales and service network with an objective <br> to emerge as India’s most trusted telematics solutions company. </h5>

               </div>

            </div>

            <div class="row white-text text-center py-5">

               <div class="col-md-12  mb-5">

                  <h2>G-TRAC DEPARTMENTS</h2>

                  <hr class="white accent-2 mt-0 d-inline-block mx-auto" style="width: 60px;">

               </div>

               <div class="col-md-12 line_1 mt-5">

                  <h3 class=""></h3>

               </div>

               <div class="col-lg-3"><img src="img/a1.png"></div>

               <div class="col-lg-3"><img src="img/a2.png"></div>

               <div class="col-lg-3"><img src="img/a3.png"></div>

               <div class="col-lg-3"><img src="img/a4.png"></div>

            </div>

            <div class="row mt-4  white-text">

               <div class="col-md-12 line_2 my-5">

                  <h3 class=""></h3>

               </div>

               <div class="col-lg-3"><img src="img/b1.png"></div>

               <div class="col-lg-3"><img src="img/b2.png"></div>

               <div class="col-lg-3"><img src="img/b3.png"></div>

               <div class="col-lg-3"><img src="img/b4.png"></div>

            </div>

         </div>

      </section>
      <?php
     include "footer.php";
      ?>






