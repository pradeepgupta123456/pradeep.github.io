

<html>
  <head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

</head>
    <body>
    <div class="w-100 text-center p-5 mt-5"><img src="img/abc.gif" class="img-fluid"></div>
    <script>
        var timer = setTimeout(function() {
            window.location='home.php'
        }, 4000);
    </script>
</body>
</html>

