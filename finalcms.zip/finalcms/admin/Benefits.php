<?php
session_start();
error_reporting(0);
include "config.php";
include "header.php";

if(isset($_POST['save'])) { // if save button on the form is clicked
  $imgid=intval($_GET['imageid']);
echo $imgid;
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  $pradeep = $_SESSION["abc"];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading, pagename) VALUES ('$imagename', '$PageDes', '$Heading', '$pradeep')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>

<style> 
.Updatedutton:nth-child(11) a{
  color:#fff;
}
.Updatedutton:nth-child(14) a{
  color:#fff;
}
.Updatedutton:nth-child(17) a{
  color:#fff;
}
.Updatedutton:nth-child(20) a{
  color:#fff;
}
.hedimg:nth-child(3) {
 display:none
}
.descritiopnclassbenefits:nth-child(4) {
  position: absolute;
    margin-top: 200px;
    margin-left: 10%;
    font-size: 1.5vw;
    font-weight: 600;
}
.hedimg:nth-child(6) {
  width: 50%;
    float: left;
    padding: 58px 80px;
}
.descritiopnclassbenefits:nth-child(7) {
  width: 50%;
    float: left;
    padding: 49px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
}
.hedimg:nth-child(9) {
 display:none
}
.descritiopnclassbenefits:nth-child(10) {
  width: 100%;
    float: left;
    padding: 68px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
    background-color: rgba(0, 0, 0, 0.56);
    color:#fff;
    font-size:22px;
    text-align:center;
}
.descritiopnclassbenefits:nth-child(10):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.hedimg:nth-child(12) {
 display:none
}
.descritiopnclassbenefits:nth-child(13) {
  width: 100%;
    float: left;
    padding: 68px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
    background-color: rgba(0, 0, 0, 0.56);
    color:#fff;
    font-size:22px;
    text-align:center;
    margin-top:2px;
}
.descritiopnclassbenefits:nth-child(13):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.hedimg:nth-child(15) {
 display:none
}
.descritiopnclassbenefits:nth-child(16) {
  width: 100%;
    float: left;
    padding: 68px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
    background-color: rgba(0, 0, 0, 0.56);
    color:#fff;
    font-size:22px;
    text-align:center;
    margin-top:2px;
}
.descritiopnclassbenefits:nth-child(16):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.hedimg:nth-child(18) {
 display:none
}
.descritiopnclassbenefits:nth-child(19) {
  width: 100%;
    float: left;
    padding: 68px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
    background-color: rgba(0, 0, 0, 0.56);
    color:#fff;
    font-size:22px;
    text-align:center;
    margin-top:2px;
}
.descritiopnclassbenefits:nth-child(19):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.Updatedutton:nth-child(5) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: 33px;
    right: 0px;
}
.Updatedutton:nth-child(8) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -403px;
    right: 0px;
}
.Updatedutton:nth-child(11) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -548px;
    right: 0px;
}
.Updatedutton:nth-child(14) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -706px;
    right: 0px;
}
.Updatedutton:nth-child(17) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -871px;
    right: 0px;
}
.Updatedutton:nth-child(20) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -1026px;
    right: 0px;
}
</style>

 <div class="solution">

 
  <form class="form-horizontal " name="insertproduct" method="post" enctype="multipart/form-data">
    
    

    <div class="control-group"> 
    <button id="hide" class="float-right">Hide</button>
      <label class="control-label" for="basicinput">Upload Image</label>
      <div class="controls">
        <input type="file" name="imagename" id="imagename" value="" class="span8 tip" required>
      </div>
      <textarea class="headingname" name="allheading" placeholder="heading"></textarea>
      <textarea id="edit" name="firstpage" placeholder="Description"></textarea>
      <div class="col-md-6">
       
        
              
    </div>
    </div>
    <div class="form-group row pt-3">
      <div class="col-12">
        <button type="submit" class="btn btn-success" name="save">
          <i class="fa fa-plus "></i> Upload
        </button>
      </div>
    </div>
  </form>
  <from class="view fm banner-marquee" name="insertproduct" method="post" enctype="multipart/form-data">

  <h1 class="pagename"><?php
     
      if(isset($_POST['submit1'])) {
    
        $pradeep = $_POST['submit1'];
       
       echo "$pradeep";
       
       $_SESSION["abc"] = $pradeep;
    
      }
      ?> </h1>
  </from>

      <?php 
     
     
      $sql = "SELECT * from imageupload where pagename='$pradeep' LIMIT 6";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
        <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
            </div>
           
            <div class="descritiopnclassbenefits"><?php echo ($result->pdescription) ?> </div>
            <div class="Updatedutton">
              <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn "><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        </div>
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
     
     
       
</div> 


    
      <?php
     include "footer.php";
      ?>






