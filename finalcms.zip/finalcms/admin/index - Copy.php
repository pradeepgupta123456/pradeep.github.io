<?php
session_start();
error_reporting(0);
include "config.php";
if(isset($_POST['save'])) { 
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading) VALUES ('$imagename', '$PageDes', '$Heading')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <title>How to update images in Mysql and php</title>
 <!--Bootstrap -->
 <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
 <link rel="stylesheet" href="css/mainadmin.css" type="text/css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script src="https://code.jquery.com/jquery-3.6.3.js"></script>
 <!-- <script>
  $(document).ready(function(){
$( "h1:contains('ABOUT US')" ).css( "text-decoration", "underline" );
});
</script> -->

</head>
<body>
<div class="topheader">
  <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
            <i class="fa fa-envelope-o pr-1" aria-hidden="true" style="color:#468e82;font-weight: bold;"></i>  info@g-trac.in
            </div>
              <div class="col-md-8 text-right">
              <div class="lockbuttonmain">
              <a class="addbutton1" href="https://gtrac.in/newtracking/reports/load_search_data_with_reports_react.php?action=search_with_reports&amp;vehicle_Number=150302&amp;ParentId=1&amp;UserName=htpl&amp;sys_group_id_parent=1&amp;sys_group_id=5435&amp;UserId=5457" target="_blank"><i class="fa fa-lock mr-2" aria-hidden="true"></i>Lock</a></div>
              <div class="headermobileno"><i class="fa fa-phone pr-1 " aria-hidden="true"></i>011 - 46254625 </div>
              </div>

       </div>
   
  </div>
</div>
<nav class="navbar navbar-expand-md navbar-light bg-white">
    <a class="navbar-brand pb-2" href="#"><img src="media/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                                        
                        <form method="post" action="index.php">
                                        <input type="submit" value="Home" name="ram" class="submenubutton">
                                        </form>
                                              
                
            </a>
            </li>
            <li class="nav-item">
                
                <a class="nav-link" href="pagedescripton.php">
                                        
                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="About us" name="ram" class="submenubutton">
                                        </form>
                                                        </a>
            </li>
           
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                        
                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value=" Solutions" name="ram" class="submenubutton">
                                        </form>
                                            
            </a>
              
                            
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                
                    <li>
                  
                    <a class="dropdown-item" href="#">
                 </a><a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Taxi and Cabs" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Tyre Pressure Remote Monitoring System" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Two Way Communication" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Solar Tracking Solution" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Weighbridge Misalignment Detection" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Alcohol Detection" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="CCTV Camera" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="GENSET Remote Monitoring" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="E-Lock" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Mobile Workforce Managment" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Transport and Logistics" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Personnel Tracking" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Fuel Monitoring" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Asset Tracking" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="School and Bus" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Heavy Machine" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Driver Behaviour" name="ram" class="submenubutton">
                                        </form>                      
         
            
          
          
                                    </a>
         
                    
    
    </li>
                   
                </ul>
             
             
            </li>
     
           
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                        
                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value=" Benefits" name="ram" class="submenubutton">
                                        </form>
                                         
            </a>
              
                            
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                
                    <li>
                  
                    <a class="dropdown-item" href="#">
                 </a><a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Fleet Management" name="ram" class="submenubutton">
                                        </form>                      
          
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Driver Behavior" name="ram" class="submenubutton">
                                        </form>                      
          
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Reporting" name="ram" class="submenubutton">
                                        </form>                      
          
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Maintenance" name="ram" class="submenubutton">
                                        </form>                      
          
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Metrics Dashboard" name="ram" class="submenubutton">
                                        </form>                      
          
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Routing and Scheduling" name="ram" class="submenubutton">
                                        </form>                      
          
            
          
          
                                    </a>
         
                    
    
    </li>
                   
                </ul>
             
             
            </li>
     
           
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                
                                        
                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Products" name="ram" class="submenubutton">
                                        </form>
                                                       
            </a>
              
                            
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                
                    <li>
                  
                    <a class="dropdown-item" href="#">
                        
                 </a><a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="WT10BLE" name="ram" class="submenubutton">
                                        </form>                      
     
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="MT10P" name="ram" class="submenubutton">
                                        </form>                      
     
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="FC10P" name="ram" class="submenubutton">
                                        </form>                      
     
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="AM10P" name="ram" class="submenubutton">
                                        </form>                      
     
            
          
          
                                    </a>
         
                     <a href="" class="sidebar-link">
                                        <i class="mdi mdi-tablet"></i>
                                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="DBM10P" name="ram" class="submenubutton">
                                        </form>                      
     
            
          
          
                                    </a>
         
                    
    
    </li>
                   
                </ul>
             
             
            </li>
            <li class="nav-item">
                
                <a class="nav-link" href="pagedescripton.php">
                                        
                        <form method="post" action="pagedescripton.php">
                                        <input type="submit" value="Customers" name="ram" class="submenubutton">
                                        </form>
                                                        </a>
            </li>
          
            
           
        </ul>
       
    </div>



    <a href="track_us.php"><div class="addbutton">TRACK US</div></a>


</nav>
 <div class="">
  <form class="form-horizontal " name="insertproduct" method="post" enctype="multipart/form-data">
    <div class="control-group"> 
      <label class="control-label" for="basicinput">Upload Image</label>
      <div class="controls">
        <input type="file" name="imagename" id="imagename" value="" class="span8 tip" required>
      </div>
      <textarea id="edit" name="firstpage" placeholder="Description"></textarea>
      <textarea name="allheading" placeholder="heading"></textarea>
    </div>
    <div class="form-group row pt-3">
      <div class="col-12">
        <button type="submit" class="btn btn-success" name="save">
          <i class="fa fa-plus "></i> Upload
        </button>
      </div>
    </div>
  </form>

  

      <?php 
      $sql = "SELECT * from imageupload where id='18'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
            <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
            <div class="Updatedutton">
              <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        </div>
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
      $sql = "SELECT * from imageupload where id='19'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
        <div class="container mt-5">
        <div class="row">
        <div class="col-md-6">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-md-6">
            <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
            <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
       
            <div class="Updatedutton text-right" style="margin-right: -119px;">
              <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        </div>
        </div>
        </div>
        </div>
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
      $sql = "SELECT * from imageupload where id='20'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        <div class="firstbackgroundcolor mt-5">
        <div class="container mt-5">
        <div class="row">
        <!-- <div class="col-md-6">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div> -->
            <div class="col-md-12">
            <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
            <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
       
            <div class="Updatedutton text-right" style="margin-right: -119px;">
              <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
        </div>
        </div>
        </div>
        </div>
        </div>
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <div class="container-fluid">
      <div class="row">
      <?php 
      $sql = "SELECT * from imageupload where id='21'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="col-4 ornge icon-box">
               <div class="text-center">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
                    <div class="headclass"><h6><?php echo ($result->heading) ?></h6> </div>
                    <div class="descritiopnclass text-center"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right">
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
      $sql = "SELECT * from imageupload where id='22'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="col-4 blue icon-box">
               <div class="text-center">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
                    <div class="headclass"><h6><?php echo ($result->heading) ?></h6> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right">
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
      $sql = "SELECT * from imageupload where id='23'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="col-4 red icon-box">
               <div class="text-center">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
                    <div class="headclass"><h6><?php echo ($result->heading) ?></h6> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>



   </div>
</div> 
</div> 
<section>
  <div class="container mt-5">
<?php 
      $sql = "SELECT * from imageupload where id='24'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      <?php 
      $sql = "SELECT * from imageupload where id='25'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <?php 
      $sql = "SELECT * from imageupload where id='26'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <?php 
      $sql = "SELECT * from imageupload where id='27'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <?php 
      $sql = "SELECT * from imageupload where id='28'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
       <?php 
      $sql = "SELECT * from imageupload where id='29'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
     
            <div class="row">
               <div class="col-lg-1 col-xl-1 col-md-2">
           
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="col-lg-11 col-xl-11 col-md-10">
                    <div class="headclass"><h4><?php echo ($result->heading) ?></h4> </div>
                    <div class="descritiopnclass"><?php echo ($result->pdescription) ?> </div>
              
                    <div class="Updatedutton text-right" >
                      <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                    </div>
                    
                </div> 
                
            </div>
       
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      </div>
</section>
<section>

         <div class="container">

            <div class="row">

               <div class="col-lg-1 timeline_circle ">

                  <h3>2010</h3>

                  <h6>January</h6>

                  <p>ITG Telematics Pvt.Ltd</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2010</h5>

                  <h6>November</h6>

                  <img src="img/tl_10.png" class="img-fluid">

                  <h6>1000 Subscribers</h6>

                  <p>Tested the waters and ready to swim.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2011</h5>

                  <h6>January</h6>

                  <img src="img/tl_11.png" class="img-fluid">

                  <h6>Repair Centre</h6>

                  <p>In-house repair team to expedite service standards.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2011</h5>

                  <h6>March</h6>

                  <img src="img/tl_11a.png" class="img-fluid">

                  <h6>Mobile Apps</h6>

                  <p>To meet the demand for "reports on the go" </p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2012</h5>

                  <h6>May</h6>

                  <img src="img/tl_11b.png" class="img-fluid">

                  <h6>Let's Explore</h6>

                  <p>Jaipur branch started as the first expansion initiative</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2013</h5>

                  <h6>February</h6>

                  <img src="img/tl_12.png" class="img-fluid">

                  <h6>Big Clients</h6>

                  <p>Maruti and Lubrizol on board for supply-chain management.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2014</h5>

                  <h6>March</h6>

                  <img src="img/tl_12a.png" class="img-fluid">

                  <h6>More Branches</h6>

                  <p>More branches and service centers started.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2014</h5>

                  <h6>February</h6>

                  <img src="img/tl_13.png" class="img-fluid">

                  <h6>Short code</h6>

                  <p>Tested the waters and ready to swim.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2015</h5>

                  <h6>March</h6>

                  <img src="img/tl_13a.png" class="img-fluid">

                  <h6>DIMTS</h6>

                  <p>Empanelment with Dept. of Telecom,(DOT) / Transport.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2016</h5>

                  <h6>November</h6>

                  <img src="img/tl_13b.png" class="img-fluid">

                  <h6>Kanpur Police</h6>

                  <p>Control center for PCR vehicles tracking.</p>

               </div>

               <div class="col-lg-1 ico_edit stripe">

                  <h5>2017</h5>

                  <h6>july</h6>

                  <img src="img/tl_14.png" class="img-fluid">

                  <h6>PSUs added</h6>

                  <p>Company has added more than 15 PSU clients in 2014 and added Big Clients like Aggarwal Movers</p>

               </div>

               <div class="col-lg-1 ico_edit">

                  <h5>2018</h5>

                  <h6>March</h6>

                  <img src="img/tl_15.png" class="img-fluid">

                  <h6>Reliance Jio</h6>

                  <p>Recieved an order for 300 subscribers, potential is 2000 subscribers.</p>

               </div>

            </div>

         </div>

      </section>
</body>
</html>





