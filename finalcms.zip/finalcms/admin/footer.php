<!-- Owl Slider  -->
<script src="js/owl.carousel.js.download"></script>

<script>
    $('.owl-carousel').owlCarousel({
    loop:true,
    margin:15,
    nav:true,
    items: 4,
    autoplay:true,
    autoplayTimeout:1500,
    autoplayHoverPause:true,
    responsive:{
        0:{
             items:1
         },
         574:{
             items:2
         },
         600:{
             items:2
         },
         800:{
             items:3
         },
         1000:{
             items:4
         },
      
     }
    
})
</script>
<footer class="page-footer grey darken-1">
        <!--Footer Links-->
        <div class="container-fluid mt-5 mb-4 text-center text-md-left">
            <div class="row mt-3">

                <!--First column-->
                <div class="col-md-3 col-lg-3 col-xl-3 mb-4">
                    <h6 class="text-uppercase font-weight-bold mb-2 ">
                                Our Company
                            </h6>
                    <hr class="orange accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 30px;">
                    <p>As an epitome of trust and stable solutions ensuring 99% uptime, our Fleet Management Solutions strives to excel with world class technology and expertise aspiring to bring together the largest network of state of the art GPS hardware, software and PAN India support services.</p>
                </div>
                <!--/.First column-->

                <!--Second column-->
                <div class="col-md-2 col-lg-2 col-xl-2 mb-4 secline">
                    <h6 class="text-uppercase font-weight-bold mb-2">
                                Links
                            </h6>
                    <hr class="orange accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 30px;">
                    <p>
                        <a href="home">Home</a>
                    </p>
                    <p>
                        <a href="about">About Us</a>
                    </p>
                  <p>
                     <a href="solutions_Taxi_and_Cabs">Our Solutions</a>
                  </p>
                  <p>
                     <a href="Fleet_Management">Our Benefits</a>
                  </p>
                  <p>
                     <a href="Product-WT10BLE">Our Products</a>
                  </p>
                  <p>
                     <a href="customers">Our Customers</a>
                  </p>
                  <p>
                     <a href="track_us">Track us</a>
                  </p>
                </div>
                <!--/.Second column-->

                <!--Third column-->
                <div class="col-md-2 col-lg-2 col-xl-2 mb-4 threeline">
                    <h6 class="text-uppercase font-weight-bold mb-2">
                                services
                            </h6>
                    <hr class="orange accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 30px;">
                    <p>
                        <a href="Industry_Specified_Telematcs">Telematics Solutions</a>
                    </p>
                    <p>
                        <a href="Software_as_a_service">Software as a Service (SAAS)</a>
                    </p>
                    <p>
                        <a href="Common_tracking_Platform">Common Tracking Platform</a>
                    </p>
                    <p>
                        <a href="Field_service_network">Field Service Network (PAN INDIA)</a>
                    </p>
                </div>
                <!--/.Third column-->

                <!--Fourth column-->
                <div class="col-md-2 col-lg-2 col-xl-2 mb-4 ">
                    <h6 class="text-uppercase font-weight-bold mb-2">
                                policy
                            </h6>
                    <hr class="orange accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 30px;">
                    <p>
                        <a href="privacy_policy.php">Privacy Policy</a>
                    </p>
                    <p>
                        <a href="Terms_and_Conditions.php">Terms &amp; Conditions</a>
                    </p>
                    <p>
                        <a href="#!" data-toggle="modal" data-target="#myModal">Holiday List</a>
                    </p>

                </div>
                <!--/.TFourth column-->

                <!--Fourth column-->
                <div class="col-md-3 col-lg-3 col-xl-3">
                    <h6 class="text-uppercase font-weight-bold mb-2">
                                Contact info
                            </h6>
                    <hr class="orange accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 30px;">
                    <p>
                       B-100 2nd floor Neelkanth Building, <br>Naraina Industrial Area Phase-1,<br>New Delhi-110028</p><br>

                    <p>
                        <i class="fa fa-phone mr-3"></i>  + 91 11 46254625 / 4915 5050</p>
                    <p>
                        <i class="fa fa-envelope mr-3"></i>info@g-trac.in</p>
                    <p>
                        <a target="_blank" href="https://goo.gl/maps/hP45itoFCT82"><i href="www.google.com/maps/dir//28.635033,77.139867/@28.635033,77.139867,16z?hl=en-US" class="fa fa-map-marker fa-lg mr-3"></i>Map Location</a></p>
                </div>
                <!--/.Fourth column-->

            </div>
        </div>
        <!--/.Footer Links-->

        <!-- Copyright-->
        <div class="footer-copyright py-3 text-center mdb-color darken-3 white-text">
            Copyright © 2010 - 2018, ITG Group of Companies, All Rights Reserved.

        </div>
 </footer>
 <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
</body>
</html>