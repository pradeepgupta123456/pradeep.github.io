
<?php
 include "config.php";
 include "header.php";
 
  
  
if(isset($_POST['submit'])) {
    $getId = $_POST['menuid'];
    $getName = $_POST['menuname'];
    $getSubmenu = $_POST['submenu'];
   
    
    $query = "INSERT INTO submenu (menuid, menuname, submenu )
    VALUES ( '$getId', '$getName',  '$getSubmenu')";
   

    if ($conn->query($query) === TRUE) {
        echo '<div class="massagepopup">New record created successfully</div>';
      
    } else {
        echo '<div class="massagepopup">Something went Wrong</div>';
    }
  
   
}
if(isset($_POST['submit'])) {
    $getId = '';
     $getName = '';
     $getSubmenu = '';
}


$sql = "SELECT menuid, menuname, submenu FROM submenu";
$result = $conn->query($sql);
echo "<table  border='1' class='one' >";
echo '<tr class="tableheaders">
<th>customer ID</th>
<th>customer name</th>
<th>submenu</th>

<tr>';
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       
echo "<tr>
<td>". $row["menuid"]. "</td>
<td>  ". $row["menuname"]."</td>
<td>  ". $row["submenu"]."</td>

</tr>";


}
} else {
    echo "0 results";
}

?>

<html>
    <head>
<script>
        $(document).ready(function () {
    $("#type").change(function () {
        var val = $(this).val();
        if (val == "Solutions") {
            $("#size").html("<option value='3'>3</option>");
        } else if (val == "Benefits") {
            $("#size").html("<option value='4'>4</option>");
        } else if (val == "Products") {
            $("#size").html("<option value='5'>5</option>");
        } 
    });
});
    </script>
    <style>
        
      .menupagelable  {
            float: left;
    width: 33%;
        }
        .p-0{padding: 0px;}
       
    </style>
    </head>
    <body>
  
  
<div class="maincover">

<form method="post" action="adminsubmenu.php" style="margin-left: 650px; margin-top:20px">
<div class="row">
<div class="col-md-2">
  <lable class="menupagelable">Menu_Id:</lable> 
   <select name="menuid" id="size" class="form-control submenumarge">
   
   <option value="3"></option>
    </select>
   </div>
<div class="col-md-4">
<lable class="menupagelable"> Menu_name:</lable>
<select name="menuname" id="type" class="form-control submenumarge">
            <option value="Solutions">Solutions</option>
            <option value="Benefits">Benefits</option>
            <option value="Products">Products</option>
  
   </select>
   </div>
   <div class="col-md-4 p-0">
   <lable class="menupagelable"> submenu:</lable>
   <input type="text" name="submenu" onfocus="this.value=''" class="form-control submenumarge">
   </div>
   <div class="col-md-2 p-0">
    <input type="submit" name="submit" value="Add Sub menu" class="buttonstylesubmenu">
    </div>
    </div>
</form>

</div>
<script src="adminall/app.min.js.download"></script>
<script src="adminall/app-style-switcher.js.download"></script>
<!-- slimscrollbar scrollbar JavaScript -->


<script src="adminall/perfect-scrollbar.jquery.min.js.download"></script>
<!--Wave Effects -->

</body>

</html>