<?php
session_start();
error_reporting(0);
include "config.php";
include "header.php";

if(isset($_POST['save'])) { // if save button on the form is clicked
  $imgid=intval($_GET['imageid']);
echo $imgid;
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  $pradeep = $_SESSION["abc"];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading, pagename) VALUES ('$imagename', '$PageDes', '$Heading', '$pradeep')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>

<style> 
.maindiv h1{
  font-size:22px;
}
.maindiv{
  float: left;
    margin-top: -1268px;
}
.solution .hedimg:nth-child(2) img{
  width:100%;
  height:398px;
} 

.leftmenubaradmin{
  display:none;
}

.productsheading{
  position:absolute;
  font-size: 56px;
    font-weight: bold;
    text-align: center;
    margin-top: 71px;
    z-index: 999999;
    width: 100%;
  
}
.bold-text {
    font-weight: 600;
}
.spe_list {
    display: flex;
    flex-wrap: wrap;
    margin: 22px 0;
}
.margineand {
    flex: 1 50%;
    margin-bottom: 15px;
    border-bottom: 1px solid #fbfafa;
    padding-bottom: 5px;
}
section {
    display: block;
}
.por-header {
    background: #eae8e8;
    padding: 15px;
    text-align: left;
    color: #000;
    font-weight: bold;
    width: 100%;
    margin-bottom: 40px;
    font-size: 25px;
    border-radius: 5px;
}
.headclass:nth-child(3) {
  font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 100%;
    FLOAT: LEFT;
    height: 409px;
    position: absolute;
    top: 172px;
    text-align: center;
}

.headclass:nth-child(7) {
  margin-left: 10%;
    WIDTH: 146PX;
    FLOAT: LEFT;
    margin-top: 78px;
    margin-bottom: 200px;
}
.headclass:nth-child(7) h1 {
  font-size: 68px;
    font-weight: bold;
|}
.headclass:nth-child(11) {
  margin-left: 6%;
    font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 47%;
    FLOAT: LEFT;
}
.headclass:nth-child(11) h1 {
  font-size:30px;
}
.headclass:nth-child(43) {
  margin-left: -2.4%;
    font-weight: 600;
    WIDTH: 27%;
    FLOAT: LEFT;
    text-align: left;
    margin-bottom: 24px;
}
.headclass:nth-child(47) {
    font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 100%;
    FLOAT: LEFT;
    text-align:center;
    margin-top: 21px;
}
.headclass:nth-child(47) h1 {
  color: rgb(242, 151, 54);
}

.headclass:nth-child(51) {
  margin-left: 14%;
    font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 40%;
    FLOAT: LEFT;
    text-align: left;
    position: absolute;
    top: 1740px;
}
.headclass:nth-child(55) {
  margin-left: 57%;
    WIDTH: 35%;
    FLOAT: LEFT;
    text-align: left;
    position: absolute;
    bottom: -1300px;
}
.headclass:nth-child(55) h1{
  font-size:35px;
}
.descritiopnclassposabsolution:nth-child(4) {
  position: absolute;
    margin-top: -242px;
    margin-left: 7%;
    font-size: 1.5vw;
    font-weight: 600;
    margin-right: 7%;
}
.descritiopnclassposabsolution:nth-child(12) {
  margin-left: 6%;
    font-size: 1.5vw;
    font-weight: 600;
    width: 46%;
    float: left;
}
.descritiopnclassposabsolution:nth-child(16) {
    font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 522px;
    margin-right: 349px;
}
.descritiopnclassposabsolution:nth-child(28) {
     font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 703px;
    margin-right: 349px;
}
.descritiopnclassposabsolution:nth-child(32) {
    font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 763px;
    margin-right: 349px;
}
.descritiopnclassposabsolution:nth-child(36) {
  font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 826px;
    margin-right: 349px;
}
.descritiopnclassposabsolution:nth-child(40) {
  margin-right: 349px;
    font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 892px;
}
.descritiopnclassposabsolution:nth-child(44) {
  float: left;
    width: 20%;
    margin-left: 7%;
    font-size: 19px;
  }

  .descritiopnclassposabsolution:nth-child(48) {
    float: left;
    width: 100%;
    text-align: center;
    font-size: 23px;
    font-weight: 400;
    margin-top: 10px;
    margin-bottom: 33px;
  }
  .descritiopnclassposabsolution:nth-child(52) {
    width: 32%;
    margin-left: 13.7%;
    text-align: left;
    position: absolute;
    z-index: 8;
    top: 1853px;
    font-size: 1.6rem;
  }
  .descritiopnclassposabsolution:nth-child(56) {
    width: 33%;
    margin-left: 57.2%;
    text-align: center;
    position: absolute;
    z-index: 9999999999;
    top: 1938px;
    float: left;
    text-align: left;
    font-size: 24px;
    font-weight: 700;
    color: rgb(242, 151, 54);
    line-height: 50px;
  }
  .descritiopnclassposabsolution:nth-child(56):before {
    width: 8px;
    height: 8px;
    background-color: rgb(242, 151, 54);;
    content: "";
    margin-top: 24px;
    margin-right: 20px;
    float: left;
  }
  .descritiopnclassposabsolution:nth-child(60) {
    width: 33%;
    margin-left: 57.2%;
    text-align: center;
    position: absolute;
    z-index: 9999999999;
    top: 1999px;
    float: left;
    text-align: left;
    font-size: 24px;
    font-weight: 700;
    color: rgb(242, 151, 54);
    line-height: 50px;
  }
  .descritiopnclassposabsolution:nth-child(60):before {
    width: 8px;
    height: 8px;
    background-color: rgb(242, 151, 54);;
    content: "";
    margin-top: 24px;
    margin-right: 20px;
    float: left;
  }
  .descritiopnclassposabsolution:nth-child(64) {
    width: 33%;
    margin-left: 57.2%;
    text-align: center;
    position: absolute;
    z-index: 9999999999;
    top: 2060px;
    float: left;
    text-align: left;
    font-size: 24px;
    font-weight: 700;
    color: rgb(242, 151, 54);
    line-height: 50px;
  }
  .descritiopnclassposabsolution:nth-child(64):before {
    width: 8px;
    height: 8px;
    background-color: rgb(242, 151, 54);;
    content: "";
    margin-top: 24px;
    margin-right: 20px;
    float: left;
  }
  .descritiopnclassposabsolution:nth-child(68) {
    width: 33%;
    margin-left: 57.2%;
    text-align: center;
    position: absolute;
    z-index: 9999999999;
    top: 2120px;
    float: left;
    text-align: left;
    font-size: 24px;
    font-weight: 700;
    color: rgb(242, 151, 54);
    line-height: 50px;
  }
  .descritiopnclassposabsolution:nth-child(68):before {
    width: 8px;
    height: 8px;
    background-color: rgb(242, 151, 54);;
    content: "";
    margin-top: 24px;
    margin-right: 20px;
    float: left;
  }
.descritiopnclassposabsolution:nth-child(20) {
    font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 579px;
    margin-right: 349px;
}
.descritiopnclassposabsolution:nth-child(24) {
    font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 639px;
    margin-right: 349px;
}

.hedimg:nth-child(6) {
  width: 50%;
    float: left;
    padding: 14px;
    margin-left: 32px;
}
.hedimg:nth-child(10) {
display:none;
}
.hedimg:nth-child(14) {
width:17%;
float: left;
margin-top: -94px;
}
.hedimg:nth-child(18) {
display:none;
}
.hedimg:nth-child(22) {
display:none;
}
.hedimg:nth-child(26) {
display:none;
}
.hedimg:nth-child(30) {
display:none;
}
.hedimg:nth-child(34) {
display:none;
}
.hedimg:nth-child(38) {
display:none;
}
.hedimg:nth-child(42) {
  float: left;
    margin-left: 8%;
    margin-top: -120px;
  }
  .hedimg:nth-child(50) {
  float: left;
    margin-left: 4%;
    margin-top: 38px;
    width:45%;
  }
  .hedimg:nth-child(54) {
  float: left;
    margin-top: 39px;
    width:45%;
  }
  .hedimg:nth-child(58) {
  display:none;
  }
  .hedimg:nth-child(62) {
  display:none;
  }
  .hedimg:nth-child(66) {
  display:none;
  }


  .headclass:nth-child(43) h1{
    font-size:22px;
    font-weight:bold;
    text-align:center;
  }
  .hedimg:nth-child(46) {
    display:none;

  }

.descritiopnclassproduct:nth-child(7) {
  width: 50%;
    float: left;
    padding: 49px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
}
.hedimg:nth-child(11) {
 display:none
}
.descritiopnclassproduct:nth-child(10) {
  width: 100%;
    float: left;
    padding: 68px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
    background-color: rgba(0, 0, 0, 0.56);
    color:#fff;
    font-size:22px;
    text-align:center;
}
.descritiopnclassproduct:nth-child(10):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;78/    *63-+21
}
.hedimg:nth-child(12) {
 display:none
}
.descritiopnclassproduct:nth-child(13) {
 background: #eae8e8;
    padding: 15px;
    text-align: left;
    color: #000;
    font-weight: bold;
    width: 91%;
    font-size: 25px;
    border-radius: 5px;
    float: left;
    margin-left: 62px;
}


.descritiopnclassproduct:nth-child(17) {
  float: left;
  margin-top:36px
}
.descritiopnclassproduct:nth-child(16):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.hedimg:nth-child(15) {
  width:100px;
  float:left;

}
.hedimg:nth-child(19) {
  width:100px;
  float:left;

}
.hedimg:nth-child(23) {
  width:100px;
  float:left;
}
.hedimg:nth-child(27) {
  width:100px;
  float:left;
}
.hedimg:nth-child(31) {
  width:100px;
  float:left;
}
.hedimg:nth-child(35) {
  width:100px;
  float:left;
}
.hedimg:nth-child(39) {
  width:100px;
  float:left;
}
.hedimg:nth-child(43) {
  width:100px;
  float:left;
}
.hedimg:nth-child(47) {
  width:100px;
  float:left;
}


.descritiopnclassproduct:nth-child(21) {
width: 17%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(25) {
width: 11%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(29) {
width: 11%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(33) {
width: 19%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(37) {
width: 19%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(41) {
width: 15%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(45) {
width: 15%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(49) {
width: 15%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}



.descritiopnclassproduct:nth-child(19):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.Updatedutton:nth-child(5) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: 133px;
    right: 0px;
}
.Updatedutton:nth-child(9) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: left;
    margin-left: 23%;
    float: left;
    margin-top: 262px;
}
.Updatedutton:nth-child(13) {
  width: 5%;
    font-size: 18px;
    text-align: left;
    margin-left: -9%;
    float: left;
    margin-top: 55px;
}
.Updatedutton:nth-child(30) {
 width: 10%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(34) {
 width: 10%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(38) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(42) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(46) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(50) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}


.Updatedutton:nth-child(11) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -548px;
    right: 0px;
}
.Updatedutton:nth-child(14) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -706px;
    right: 0px;
    display:none;
}
.Updatedutton:nth-child(17) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    float: left;
    margin-top: -54px;
}
.Updatedutton:nth-child(21) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    float: left;
    margin-top: 4px;
    position: relative;
}
.Updatedutton:nth-child(25) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 66px;
    position: relative;
}
.Updatedutton:nth-child(29) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 129px;
    position: relative;
}
.Updatedutton:nth-child(33) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 190px;
    position: relative;
}
.Updatedutton:nth-child(37) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 252px;
    position: relative;
}
.Updatedutton:nth-child(41) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 318px;
    position: relative;
}

.Updatedutton:nth-child(45) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 110px;
    position: relative;
}
.Updatedutton:nth-child(49) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-right: 1%;
    float: right;
    margin-top: -61px;
}
.Updatedutton:nth-child(53) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 42%;
    float: right;
    margin-top: 1660px;
    position: absolute;
}
.Updatedutton:nth-child(57) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 88%;
    float: right;
    margin-top: 1445px;
    position: absolute;
}
.Updatedutton:nth-child(61) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 88%;
    float: right;
    margin-top: 1510px;
    position: absolute;
}
.Updatedutton:nth-child(65) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 88%;
    float: right;
    margin-top: 1576px;
    position: absolute;
}
.Updatedutton:nth-child(69) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 88%;
    float: right;
    margin-top: 1634px;
    position: absolute;
}

.Updatedutton:nth-child(30) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 114px;
    position: relative;
}

.Updatedutton:nth-child(20) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -1026px;
    right: 0px;
}
</style>
 <div class="solution">
 
 
  <form class="form-horizontal " name="insertproduct" method="post" enctype="multipart/form-data">
    
    

    <div class="control-group"> 
    <button id="hide" class="float-right">Hide</button>
      <label class="control-label" for="basicinput">Upload Image</label>
      <div class="controls">
        <input type="file" name="imagename" id="imagename" value="" class="span8 tip" required>
      </div>
      <textarea class="headingname" name="allheading" placeholder="heading"></textarea>
      <textarea id="edit" name="firstpage" placeholder="Description"></textarea>
      <div class="col-md-6">
       
        <a class="pagename "><?php
     
      if(isset($_POST['submit1'])) {
    
        $pradeep = $_POST['submit1'];
       
       echo "$pradeep";
       
       $_SESSION["abc"] = $pradeep;
    
      }
      ?> </a>
  
              
    </div>
    </div>
    <div class="form-group row pt-3">
      <div class="col-12">
        <button type="submit" class="btn btn-success" name="save">
          <i class="fa fa-plus "></i> Upload
        </button>
      </div>
    </div>
  </form>

  <?php 
     
     
     $sql = "SELECT * from imageupload where pagename='$pradeep' LIMIT 17";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
         ?>	
       
     
           <div class="hedimg">
             <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
           </div>
           <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
           <div class="descritiopnclassposabsolution"><?php echo ($result->pdescription) ?> </div>
           <div class="Updatedutton">
             <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn "><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
       </div>
      
         <?php
         $cnt=$cnt+1;
       }
     } ?>

</div>

   <!-- <div id="target" class="maindiv"></div>
   <div id="target" class="maindivdes"></div> -->
</section>
   
       
</div> 

<script>
      $('.headclass:nth-child(11)').clone().appendTo('.maindiv');
   </script>
    
      <?php
     include "footer.php";
      ?>






