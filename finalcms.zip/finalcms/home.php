<?php
session_start();
error_reporting(0);
include "admin/config.php";
include "header.php";


?>
<script>
    $(document).ready(function () {
  $('#carousel-example-2').find('.carousel-item').first().addClass('active');
});
</script>
<style>
      /* <----------------Start 16mar23---------------> */
      .infographic{
        padding-bottom:100px;
      }
      .rightbottom{
margin-top: 60px;
      }
      #thumbnail-slider {
    margin: 10px auto;
    width: 100%;
    max-width: 92%;
    padding: 20px;
    box-sizing: border-box;
    position: relative;
    -webkit-user-select: none;
    user-select: none;
    margin-left: 33px;
}
      .leftfirsttop{
        float: left;
    width: 100%;
    text-align: right;
    }
.leftfirstbottom{
    float: left;
    width: 100%;
    margin-top: 60px;
    text-align: right;
}
    
.in1{
    width: 31%;
    float: left;
    padding-left: 35px;
   }
    .in2{
    width: 28%;
    float: right;
   
   }
    .marginlefthome{
        margin-left:32%;
    }
    input::file-selector-button {
  font-weight: bold;
  color: #000;
  padding: 0.5em;
  border: thin solid #468e82;
  border-radius: 3px;
  background-color: transparent;
}
.headingtext {
    font-size: 1.4rem;
    font-weight: 500;
    margin-bottom: 40px;
    line-height: 40px;
}
h1 {
        font-size: 32px;
    font-weight: bold;
    margin-bottom: 20px;
    text-align: center;
    margin-top: 4px;
}
h1:after, h1:before {
    content: "\A";
    width: 30px;
    height: 4px;
    background: #b83b3b;
    display: inline-block;
    margin: 6px 10px;
}
/* <----------------End 16mar23---------------> */
    .homeimportant{
        margin-top:6px;
    }
    .form-horizontal {
        display:none;
    }
    .carousel-caption p {
    font-size: 2.4vw;
    font-weight: 600;
    line-height: 3rem;
    color: #1c1a1a;
}
    .carousel-caption {
    position: absolute;
    right: 0;
    bottom: 20px;
    left: 50%;
    z-index: 10;
    padding-top: 20px;
    padding-bottom: 20px;
    color: #fff;
    text-align: center;
}
    .h3-responsive{
    display: block;
    font-size: 70px;
    font-weight: bolder;
    color: #fff;
}
    .leftmenubaradmin{
        display:none;
    }
    .industarydiv{
        float: left;
    width: 100%;
    margin-bottom: 30px;
    }
    .right_blk .rghtdiv aside {
    font-size: 1.1rem;
    font-weight: 400;
    color: rgba(255,255,255,1.00);
    position: absolute;
    left: 159px;
    top: 42px;
}
    .Schedule_a_Demo {
    background-color: rgb(252, 184, 52);
    border-radius: 30px;
    font-size: 1.0rem;
    color: rgba(0,0,0,1.00);
    padding: 10px 16px;
    position: absolute;
    right: -50px;
    top: 50px;
    font-weight: 600;
}
    .unique-color-dark {
        background-color: #1c2331!important;
    height: 130px;
    float: left;
    width: 100%;
}
    .sunny-morning-gradient {
    position: relative;
    z-index: 9;
    height: 152px;
    top: -22px;
    width: 39%;
    float: left;
    padding-top: 30px;
}
    .left-shape:before {
    content: "";
    position: absolute;
    border: 76px solid transparent;
    border-left-width: 29px;
    border-right-width: 29px;
    border-bottom-color: rgba(253,187,53,1.00);
    border-left-color: rgba(253,187,53,1.00);
    left: 100%;
    top: 0px;
    width: 0;
    height: 0;
}
    .right_blk {
    padding: 20px 0 0px 30px;
    position: relative;
    left: 40px;
    float: left;
}
    .left-shape {
    color: white;
    font-size: 18px;
    padding: 26px 20px 10px 80px;
    background-image: -webkit-linear-gradient( 0deg, rgb(242,141,33) 0%, rgb(248,165,44) 25%, rgb(253,188,54) 100%);
    background-image: -ms-linear-gradient( 0deg, rgb(242,141,33) 0%, rgb(248,165,44) 25%, rgb(253,188,54) 100%);
    position: relative;
    margin-left: 50px px;
}
   
    .elementor-widget-container img {
    width: 564px;
    height: 424px;
    margin-left: ;
}
.infographic .inner span img{
    margin-top:5px;
}
.infographic .inner span {
   
    align-items: center;
    justify-content: center;
    border-radius: 100%;
    width: 65px;
    height: 65px;
    padding: 7px;
    margin-right: 16px;
    text-align: center;
    -webkit-box-shadow: 0 15px 15px 0 #bdb5b5;
    display:inline-block;
    margin-bottom: 8px;
}
.infographic .inner h3 {
    margin: 6px;
    font-size: 17px;
    font-weight: bold;
    border-bottom: 1px solid #ddd;
    width: auto;
    display: inline-block;
    padding: 0px 0 5px 0;
    margin-bottom: 8px;
    color: #000;
}
.strip_01 {
    background: url(img/looking4.jpg);
    width: 100%;
    clear: both;
    height: 135px;
    margin-bottom: 10px;
    background-attachment: fixed;
}
.left_heading {
    color: rgb(243, 166, 47);
    font-size: 1.9rem;
    font-weight: 800;
    margin-top: 15px;
}
.left_heading span {
    color: rgb(255, 255, 255);
}
.left_heading p {
    font-size: 1.22rem;
    color: rgb(255, 255, 255);
    padding-top: 10px;
    font-weight: 400;
}
.available_btn {
    background-image: -webkit-linear-gradient( 180deg, rgb(248, 154, 54) 0%, rgb(253, 186, 55) 100%);
    background-image: -ms-linear-gradient( 180deg, rgb(248, 154, 54) 0%, rgb(253, 186, 55) 100%);
    color: rgba(255,255,255,1.00);
    border-radius: 0 35px 0 35px;
    border: none;
    font-size: 1.3rem;
    font-weight: 900;
    line-height: 24px;
    -webkit-text-stroke-width: 0.999px;
    -webkit-text-stroke-color: rgba(0,0,0,0.10);
    float: right;
    padding: 14px 20px;
    margin-top: 13px;
}
.view img{
        height:500px;
        width: 100%;
    }
</style>


 
<div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
    <!--Indicators-->
    <ol class="carousel-indicators">
      <li data-target="#carousel-example-2" data-slide-to="0" class=""></li>
      <li data-target="#carousel-example-2" data-slide-to="1" class="active"></li>
      <li data-target="#carousel-example-2" data-slide-to="2" class=""></li>
    </ol>
    <!--/.Indicators-->
    <!--Slides-->
    <div class="carousel-inner" role="listbox" style="height: 483px;">
    
    
       <?php 
     
     
     $sql = "SELECT * from images ORDER BY id DESC LIMIT 3";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
        ?>	
      <div class="carousel-item">
        <!--Mask color-->
        <div class="view">
        <img class="img-fluid" src="admin/uploads/<?php  echo $result->file_name?>" alt="Image"/>
          <div class="mask rgba-black-strong"></div>
        </div>
       
      </div>
      <?php
         $cnt=$cnt+1;
       }
     } 
     
     ?>
    </div>
   
    <!--/.Slides-->
    <!--Controls-->
    <a class="carousel-control-prev" href="#carousel-example-2" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carousel-example-2" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
    <!--/.Controls-->
  </div>
<div class="w-100">
    <?php
session_start();
error_reporting(0);
include "config.php";
if(isset($_POST['save'])) { 
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading) VALUES ('$imagename', '$PageDes', '$Heading')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>



 <div class="">
  <form class="form-horizontal " name="insertproduct" method="post" enctype="multipart/form-data">
    <div class="control-group"> 
      <label class="control-label" for="basicinput">Upload Image</label>
      <div class="controls">
        <input type="file" name="imagename" id="imagename" value="" class="span8 tip" required>
      </div>
      <textarea id="edit" name="firstpage" placeholder="Description"></textarea>
      <textarea name="allheading" placeholder="heading"></textarea>
    </div>
    <div class="form-group row pt-3">
      <div class="col-12">
        <button type="submit" class="btn btn-success" name="save">
          <i class="fa fa-plus "></i> Upload
        </button>
      </div>
    </div>
  </form>

  

      
      
      
       <div class="container-fluid">
      <div class="row">
      
      
      



   </div>
</div> 
</div> 



<div class="pradeep">
    
<?php 
     
     
     $sql = "SELECT * from imageupload where id='143'";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
         ?>	
       
        <div class="container text-center">
           <!-- <div class="hedimg">
             <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
           </div> -->
           <div class="headclass homeimportant"><h1><?php echo ($result->heading) ?></h1> </div>
           <div class="descritiopnclassposabsolution headingtext"><?php echo ($result->pdescription) ?> </div>
         
       </div>
         <?php
         $cnt=$cnt+1;
       }
     } ?>
</div>

<section>

        <!-- close here -->

         <div class="col-lg-12 col-xl-12 mb-3 mt-2 ">

            <div class="infographic">
              <div class="row">             
               <div class="col-md-6 marginlefthome">
                <div class="out-focus in-focus">
                  <div class="blank-builder">		
				   <div data-elementor-type="wp-page" data-elementor-id="20" class="elementor elementor-20">
				     <section class="elementor-section elementor-top-section elementor-element elementor-element-6970a18 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6970a18" data-element_type="section">
						<div class="elementor-container elementor-column-gap-custom">
					     <div class="elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-e1b0b8f" data-id="e1b0b8f" data-element_type="column">
			                <div class="elementor-widget-wrap elementor-element-populated">
							   <div class="elementor-element elementor-element-9805400 iteck-image-animation-rotate elementor-absolute elementor-widget elementor-widget-iteck-image" data-id="9805400" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="iteck-image.default">
				                 <div class="elementor-widget-container" >
				                    <img width="716" height="554" syle="margin-left:200px; float:left" src="img/about_s5_2_1.png" class="attachment-large size-large" alt="" loading="lazy">															</div>
				                 </div>
                                <div class="elementor-element elementor-element-31c84b2 iteck-image-animation-slide-up-down elementor-widget elementor-widget-iteck-image" data-id="31c84b2" data-element_type="widget" data-widget_type="iteck-image.default">
                                <div class="elementor-widget-container">
                                <img width="749" height="553" style="margin-top:-50px;margin-left:-60px" src="img/about_s5_2_2.png" class="attachment-large size-large" alt="" loading="lazy">															</div>
                                </div>
                                    </div>
                                </div>
                                
                                </div>
                     </section>
				
				
				
				
			
			</div>
		</div>	
    </div>

</div>
<div class="col-md-12 position-absolute">
                <div class="inner in1">
                <?php 
     
     
     $sql = "SELECT * from imageupload where  id='145'";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
         ?>	
                    <div class="leftfirsttop">
                    <div class="hedimg">
                        <span>
             <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
             </span>
           </div>
                   
           <div class="headclass" ><h3><?php echo ($result->heading) ?></h3> </div>
           <div class="descritiopnclassposabsolution" ><?php echo ($result->pdescription) ?> </div>
           


                    </div>
                    <?php
         $cnt=$cnt+1;
       }
     } ?>
                    <div class="leftfirstbottom">
                    <?php 
     
     
     $sql = "SELECT * from imageupload where id='147'";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
         ?>	
                    
                   
                    <div class="hedimg">
                        <span>
                          <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
                        </span>
                    </div>       
           <div class="headclass"><h3><?php echo ($result->heading) ?></h3> </div>
           <div class="descritiopnclassposabsolution"><?php echo ($result->pdescription) ?> </div>
           
         

                 
                    <?php
         $cnt=$cnt+1;
       }
     } ?>
                    </div>

                </div>


                <div class="inner in2">

                    <div class="right top">
                    <?php 
     
     
     $sql = "SELECT * from imageupload where id='149'";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
         ?>	
                    <div class="left top">
                   
                    <div class="hedimg">
                        <span>
             <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
             </span>
           </div>
           <div class="headclass"><h3><?php echo ($result->heading) ?></h3> </div>
           <div class="descritiopnclassposabsolution"><?php echo ($result->pdescription) ?> </div>
         

                    </div>
                    <?php
         $cnt=$cnt+1;
       }
     } ?>
                    </div>

                    <div class="rightbottom">
                    <?php 
     
     
     $sql = "SELECT * from imageupload where  id='149'";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
         ?>	
                    <div class="left top">
                   
                    <div class="hedimg">
                        <span>
             <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
             </span>
           </div>
           <div class="headclass"><h3><?php echo ($result->heading) ?></h3> </div>
           <div class="descritiopnclassposabsolution"><?php echo ($result->pdescription) ?> </div>
          

                    </div>
                    <?php
         $cnt=$cnt+1;
       }
     } ?>
                    </div>

                </div>
                </div>
                </div>
            </div>

        </div>
    </section>

    <section class="strip_01">

<div class="strip_01_inner">

    <div class="container">

        <div class="row">

            <div class="col-sm-12 col-md-8 col-lg-9 left_heading ">It is a commitment <span>not a campaign</span>

                <p>We all at ITG are committed to deliver your expectations.....</p>

            </div>

            <div class="col-sm-12 col-md-4 col-lg-3 mt-3">

                <button class="available_btn wow bounceInRight animated col-sm-12 col-md-12 col-lg-12"><span>AVAILABLE AND<br>IMPLEMENTED</span></button>

            </div>

        </div>

    </div>

</div>

</section>
 
<section class="special_deal_section_1">
    <h1>Our <span>Services</span></h1>
    <div class="container">
    <main class="bd-grid owl-carousel owl-loaded owl-drag">
        
            

            

            

            
            
            
          
        <div class="owl-stage-outer">
            <div class="owl-stage" style="transform: translate3d(-2531px, 0px, 0px); transition: all 0.25s ease 0s; width: 3938px;">
            <div class="owl-item cloned" style="width: 266.25px; margin-right: 15px;">
            <article class="card">
                <div class="card__img">
                    <img src="media/fleet-managment.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Fleet Management</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon">
                        <ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Fleet Management</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item cloned" style="width: 266.25px; margin-right: 15px;">
        <article class="card">
                <div class="card__img">
                    <img src="media/reporting.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Reporting</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Reporting</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item cloned" style="width: 266.25px; margin-right: 15px;">
        <article class="card">
                <div class="card__img">
                    <img src="media/maintanance.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Maintenance</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Maintenance</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item cloned" style="width: 266.25px; margin-right: 15px;">
        <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        
        <div class="owl-item" style="width: 266.25px; margin-right: 15px;">
        <article class="card">
                <div class="card__img">
                    <img src="media/dash-board .jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Dashboard</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Dashboard</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item" style="width: 266.25px; margin-right: 15px;">
        <article class="card">
                <div class="card__img">
                    <img src="media/driver-behav.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Driver Behaviour</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    <div>
                        <span class="card__preci card__preci--before">Driver Behaviour</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item" style="width: 266.25px; margin-right: 15px;">
        <article class="card">
                <div class="card__img">
                    <img src="media/fleet-managment.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Fleet Management</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Fleet Management</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item" style="width: 266.25px; margin-right: 15px;">
        <article class="card">
                <div class="card__img">
                    <img src="media/reporting.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Reporting</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Reporting</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item" style="width: 266.25px; margin-right: 15px;">
        <article class="card">
                <div class="card__img">
                    <img src="media/maintanance.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Maintenance</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Maintenance</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
            <div class="owl-item active" style="width: 266.25px; margin-right: 15px;">
             <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item active" style="width: 266.25px; margin-right: 15px;">
             <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item active" style="width: 266.25px; margin-right: 15px;">
             <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item active" style="width: 266.25px; margin-right: 15px;">
             <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item active" style="width: 266.25px; margin-right: 15px;">
             <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item active" style="width: 266.25px; margin-right: 15px;">
             <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item active" style="width: 266.25px; margin-right: 15px;">
             <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item active" style="width: 266.25px; margin-right: 15px;">
             <article class="card">
                <div class="card__img">
                    <img src="media/routing.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Routing</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Routing</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article>
        </div>
        <div class="owl-item cloned active" style="width: 266.25px; margin-right: 15px;"><article class="card">
                <div class="card__img">
                    <img src="media/dash-board .jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Dashboard</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Dashboard</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article></div><div class="owl-item cloned active" style="width: 266.25px; margin-right: 15px;"><article class="card">
                <div class="card__img">
                    <img src="media/driver-behav.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Driver Behaviour</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    <div>
                        <span class="card__preci card__preci--before">Driver Behaviour</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article></div><div class="owl-item cloned active" style="width: 266.25px; margin-right: 15px;"><article class="card">
                <div class="card__img">
                    <img src="media/fleet-managment.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Fleet Management</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Fleet Management</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article></div><div class="owl-item cloned" style="width: 266.25px; margin-right: 15px;"><article class="card">
                <div class="card__img">
                    <img src="media/reporting.jpg" alt="">
                </div>
                <div class="card__name">
                    <p>Reporting</p>
                </div>
                <div class="card__precis">
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="heart-outline"></ion-icon></a>
                    
                    <div>
                        <span class="card__preci card__preci--before">Reporting</span>
                    </div>
                    <a href="http://localhost/newcms/gtackCms/home.php" class="card__icon"><ion-icon name="cart-outline"></ion-icon></a>
                </div>
            </article></div></div></div><div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span></button></div><div class="owl-dots"><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot active"><span></span></button></div></main>
        </div>
    </section>
    <section class="special_deal_section">
    <h1>Our <span>Clients</span></h1>
         <!--start-->
    <div>

<div>
    
    <div id="thumbnail-slider">
        <div class="inner">
            <ul style="touch-action: pan-y; transition-property: transform; transition-timing-function: cubic-bezier(0.2, 0.88, 0.5, 1); transition-duration: 1500ms; transform: translateX(-935px);">
            <?php 
     
     
     $sql = "SELECT * from clientlogos ORDER BY id DESC";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
        ?>	
            <li>
                    <a class="thumb" href="admin/clientfolder/<?php  echo $result->file_name?>" alt="Image"/>
      </a>
                </li>
                <?php
         $cnt=$cnt+1;
       }
     } 
     
     ?>">
                <li>
                    <a class="thumb" href="media/client-2.png"></a>
                </li>
                <li>
                    <a class="thumb" href="media/client-3.png"></a>
                </li>
               
        </ul>
        </div>
    <div id="thumbnail-slider-prev" class=""></div><div id="thumbnail-slider-next" class=""></div><div id="thumbnail-slider-pause-play" class=""></div></div>
</div>




</div>
<!--end-->
</section>
<section class="m-0">

        <div class="unique-color-dark white-text">

            <div class="col-sm-12 col-md-4 col-lg-5 col-xl-5 left-shape sunny-morning-gradient ml-0">

                <h1 class="text-left">GPS Tracking</h1>

                <h5 style="margin-left: 69px;">WE MAKE IT EASY</h5>



            </div>

            <div class="col-sm-12 col-md-8 col-lg-6 col-xl-6 text-left right_blk">

                <div class="rghtdiv"><img src="img/24-7-icon.png" alt="">

                    <aside> Your Enquiry, Our Service

                        <br> Call Now : <span>011 - 4625 4625 / 4915 5050</span></aside>

                    <a href="track_us" class="Schedule_a_Demo example hoverable">Schedule a Demo</a>

                </div>



            </div>

        </div>

    </section>
</div>
    
      <?php
     include "footer.php";
      ?>






