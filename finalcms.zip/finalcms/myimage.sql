-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2023 at 08:29 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myimage`
--

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `banner_id` int(11) NOT NULL,
  `banner_title` varchar(200) NOT NULL,
  `banner_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`banner_id`, `banner_title`, `banner_image`) VALUES
(1, 'Banner 1', 'banner-1.jpg'),
(2, 'Banner 2', 'banner-2.jpg'),
(3, 'Banner 3', 'banner-3.jpg'),
(4, 'Banner 4', 'banner-4.jpg'),
(5, 'Banner 5', 'banner-5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `benefit`
--

CREATE TABLE `benefit` (
  `id` int(11) NOT NULL,
  `Heading` varchar(255) NOT NULL,
  `Subheading` varchar(255) NOT NULL,
  `Imagename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `benefit`
--

INSERT INTO `benefit` (`id`, `Heading`, `Subheading`, `Imagename`) VALUES
(1, 'today', 'this is today page', ''),
(7, 'Fleet Management', 'this is fleet management page', ''),
(8, 'Driver Behavior', '        this is Driver Behavior', ''),
(9, 'Fleet Management', '     that is one page', ''),
(11, 'Reporting', '        This is the reporting page', ''),
(12, 'ramkumar', '     this is ramkumar\r\n', ''),
(13, 'ddddd', '       gfdtgdtrf', ''),
(14, 'Driver Behavior', '      gsfgsfgsfg', '');

-- --------------------------------------------------------

--
-- Table structure for table `clientlogos`
--

CREATE TABLE `clientlogos` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `clientlogos`
--

INSERT INTO `clientlogos` (`id`, `file_name`, `uploaded_on`, `status`) VALUES
(58, 'client-1.png', '2023-03-15 15:38:18', '1'),
(59, 'client-2.png', '2023-03-15 15:38:18', '1'),
(60, 'client-3.png', '2023-03-15 15:38:18', '1'),
(61, 'client-4.png', '2023-03-15 15:38:18', '1'),
(62, 'client-5.png', '2023-03-15 15:38:18', '1'),
(63, 'client-6.png', '2023-03-15 15:38:18', '1'),
(64, 'client-7.png', '2023-03-15 15:38:18', '1'),
(65, 'client-8.png', '2023-03-15 15:38:18', '1'),
(66, 'client-9.png', '2023-03-15 15:38:18', '1'),
(67, 'client-10.png', '2023-03-15 15:38:18', '1'),
(68, 'abs_1.png', '2023-03-18 13:14:12', '1'),
(69, 'abs_2.png', '2023-03-18 13:14:12', '1'),
(70, 'abs_3.png', '2023-03-18 13:14:12', '1'),
(71, 'abs_4.png', '2023-03-18 13:14:12', '1');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `file_name`, `uploaded_on`, `status`) VALUES
(82, '5.jpg', '2023-03-15 14:47:01', '1'),
(83, '9.jpg', '2023-03-15 14:47:01', '1'),
(84, 'b1.jpg', '2023-03-15 15:15:35', '1'),
(85, 'b2.jpg', '2023-03-15 15:15:35', '1'),
(86, 'b3.jpg', '2023-03-15 15:15:35', '1'),
(87, '5.jpg', '2023-03-16 11:38:59', '1'),
(88, '9.jpg', '2023-03-16 11:38:59', '1'),
(89, 'abs_1.png', '2023-03-16 11:38:59', '1'),
(90, 'abs_2.png', '2023-03-16 11:38:59', '1'),
(91, 'abs_3.png', '2023-03-16 11:38:59', '1'),
(92, 'abs_4.png', '2023-03-16 11:38:59', '1'),
(93, 'abs_5.png', '2023-03-16 11:38:59', '1'),
(94, 'abs_6.png', '2023-03-16 11:38:59', '1'),
(95, 'bluecolor.png', '2023-03-16 11:38:59', '1'),
(96, 'bulb.png', '2023-03-16 11:38:59', '1'),
(97, 'client-1.png', '2023-03-16 11:38:59', '1'),
(98, 'client-1a.jpg', '2023-03-16 11:38:59', '1'),
(99, 'b1.jpg', '2023-03-16 11:39:47', '1'),
(100, 'b2.jpg', '2023-03-16 11:39:47', '1'),
(101, 'b3.jpg', '2023-03-16 11:39:47', '1'),
(102, 'products-hdr-img2.jpg', '2023-03-17 17:46:28', '1'),
(103, 'products-hdr-img3.jpg', '2023-03-17 17:46:28', '1'),
(104, 'b1.jpg', '2023-03-18 10:56:10', '1'),
(105, 'b2.jpg', '2023-03-18 10:56:10', '1'),
(106, 'b3.jpg', '2023-03-18 10:56:10', '1'),
(107, 'header-image.jpg', '2023-03-18 13:13:22', '1'),
(108, 'Our-Customer.jpg', '2023-03-18 13:13:22', '1'),
(109, 'products-hdr-img2.jpg', '2023-03-18 13:13:22', '1'),
(110, 'b1.jpg', '2023-03-18 13:13:43', '1'),
(111, 'b2.jpg', '2023-03-18 13:13:43', '1'),
(112, 'b3.jpg', '2023-03-18 13:13:43', '1');

-- --------------------------------------------------------

--
-- Table structure for table `imageupload`
--

CREATE TABLE `imageupload` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) CHARACTER SET latin1 NOT NULL,
  `pdescription` longtext NOT NULL,
  `heading` varchar(255) NOT NULL,
  `pagename` varchar(255) NOT NULL,
  `imageid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `imageupload`
--

INSERT INTO `imageupload` (`id`, `filename`, `pdescription`, `heading`, `pagename`, `imageid`) VALUES
(65, 'header-image.jpg', 'ITG Telematics was started in 2010 with its first Office in New Delhi. Since then the company has grown to a network of five own Offices, in Delhi, Mumbai, Ahmedabad, Kolkata & Jaipur along with 28 service centres and more than 400 service engineers stationed across strategic locations in India. We currently track 45000 active assets live on our server. This achievement places us among one of the leaders in the industry. We are one of the most trusted telematics solutions brands in India.', 'ABOUT US', 'About us', 0),
(66, 'vision.png', 'Our vision is to always remain as the most appreciated GPS Vehicle Tracking solutions company in India. We have clients in all types of industries including people transport, cargo and logistics, construction and mining and several Government departments.\r\n<br /><br />\r\n\r\nOur vision includes that we continue to innovate and bring required changes in the technology of GPS vehicle tracking solutions meeting customer requirements. We have vision to keep providing better GPS vehicle tracking solutions in such a simple and advanced form that all our clients and all the people associated with the transportation industry of India should feel very delighted while applying those solutions for their vehicles.', 'VISION', 'About us', 0),
(67, 'Untitled-1.jpg', 'Our G-TRAC GPS based vehicle tracking solutions is presently helping thousands of fleet owners to drive down operating costs and increase earnings. Fleet owners experience a dramatic increase in productivity, substantial fuel savings and greatly reduced operating expenses. The system enables fleet owners to locate and deploy their vehicles with live, real-time tracking and provides minute-by-minute route verification, enabling them to settle customer disputes, provide proof of service and ensure the fleet is not burning un-necessary fuel. G-TRACâ€™s key management reports enable business owners to verify time sheets accurately, leading to reduced overtime expenses, Fleet owners can compare hours worked by each vehicle thereby controlling productivity and establish exactly how much time their vehicles are spending at locations such as the supply houses, customer sites, or unauthorised locations. These reports allow for accurate validation of the cost of each site visit. The G-trac system provides numerous reports suited to tighter control and accurate measurements of fleet activity.', 'WHY G-TRAC', 'About us', 0),
(73, 'panindia.png', 'Dedicated Support Staff for Customers', 'PAN India 24 Hours Support', 'About us', 0),
(74, 'bluecolor.png', 'SMS/E-Mail/Mobile alerts for exceptions defined by Customers.', 'Dynamic Reporting', 'About us', 0),
(75, 'red-color.png', 'Stable Hardware at Competitive Pricing, More than 99% service uptime, Proven track record & references', 'Ultimate Product Quality', 'About us', 0),
(76, 'abs_4.png', 'To enable the insurer and fleet owners to assess the actual risk presented by an individual driver, based on driving behaviour and driving patterns within the road context and price that risk accordingly.', 'DRIVER BEHAVIOR', 'About us', 0),
(77, 'abs_2.png', 'Our hardware devices are installed in stealth mode and have internal battery power with immobilization features to protect and prevent theft.', 'ANTI THEFT', 'About us', 0),
(78, 'abs_3.png', 'The live temperature monitoring system can be configured to suit any customer SAP/CRM application. Our device will send live data and raise exceptions alarms to identify predefined breaches in temperature parameters.', 'TEMPERATURE MONITORING', 'About us', 0),
(79, 'abs_4.png', 'Most of fleets require basic real time tracking to view where their assets are the routes followed by them to reach their destination.', 'REAL TIME TRACKING', 'About us', 0),
(80, 'abs_5.png', 'When you have too many assets to monitor, we provide customized reporting to generate exceptions for you to monitor and act.', 'FLEET MANAGEMENT', 'About us', 0),
(81, 'abs_6.png', 'Self drive hire cars with RFID, mining & cement, JCBs runtime monitoring, Data loggers, Radio Cabs, Solid Waste Management, Stopping pilferage using flow meters.', 'APPLIED SOLUTIONS', 'About us', 0),
(82, 'solution-image.jpg', 'Managing and optimum utilization of on-road taxi demands adopting technologies to rein in real time data based controls ensuring driver, passenger safety and optimum usage of the vehicle. G-Trac offers solutions optimizing the vehicle usage, fuel consumption, monitor the operating costs, including VAS like e-records, e-pod, on-duty trips.', 'OUR SOLUTION', 'Taxi and Cabs', 0),
(83, 'taxi.jpg', 'TAXI\r\nAND', 'TAXI\r\nAND\r\nCABS', 'Taxi and Cabs', 0),
(84, 'solution-image.jpg', 'Heavy equipements for any organization is a big investment, hence making it mandatory to monitor the equipments utilization at peak performance levels like its Idling, aggressive driving, fuel waste and unauthorized or rough usage.\r\nG-Trac offers solutions enabling real time monitoring of all heavy equipements including cranes, excavators and bulldozers.', 'OUR SOLUTION', 'Heavy Machine', 0),
(85, 'bulb.png', 'Its more than just fleet tracking. Its a business tool.', 'Its more than just fleet tracking. Its a business tool.', 'Fleet Management', 0),
(86, 'fleet management.jpg', 'One of the biggest problems faced by mid size, SME transporters is absence of proven fleet management platform, including freight costs calculation.\r\n\r\nTransporters at all levels have raised voices highlighting this vacuum. ITG Telematics realising this gap now offers a complete end to end fleet management solution, accessible through a common URL and a mobile application.\r\n\r\nThe offered platform brings real-time monitoring and management of fleet, and on road managements of vehicles, further supported by asked for reports and derivatives as VAS to enable complete managements of the transport operations.\r\n\r\nThe offered solution enables fleet operators to manage, vehicle utilization including route and passenger management on real-time basis.', 'ppppppppppppp', 'Fleet Management', 0),
(87, 'final.png', 'What does your business do to ensure driver safety?', 'uuuuuuuuuuuu', 'Driver Behavior', 0),
(90, 'products-hdr-img3.jpg', 'Multifunctional tracker with 2-way communication', 'Multifunctional tracker with 2-way communication', 'MT10P', 0),
(91, 'gt066 (1).png', 'This compact vehicle tracker gives you the location of anything, at anytime. Utilizing cutting-edge GPS technology, it can help you track anything, be it your car, children, or a prized possession, all in real time. In addition to this,it supports door status detection, two-way communication as well as SOS call.', 'MT10P', 'MT10P', 0),
(92, 'heavy-machine.jpg', '', 'HEAVY\r\nMACHINE', 'Heavy Machine', 0),
(93, 'solution-image.jpg', 'Monitoring and optimization of fuel consumption, consumption pattern, and fuel level disruptions are major issues for fleet owners. In order to maximize ROI on fuel, precise and real time data regarding consumed fuel is one of the key factors for optimizing the fuel cost.', 'OUR SOLUTION', 'Fuel Monitoring', 0),
(94, 'solution-image.jpg', 'Students and School Bus safety related instances have further magnified the requirement to adopt proven solutions for managing the fleet ensuring the safety of school students. Our solution helps school transport and parents to interactively communicate with school buses on real time basis, monitor the location, receive instant ETA/ETD alarms.', 'OUR SOLUTION', 'School and Bus', 0),
(95, 'school-bus.jpg', '', 'SCHOOL\r\nAND\r\nBUSES', 'School and Bus', 0),
(100, 'abs_4.png', 'Fleet reporting tools', 'REPORTING', 'Reporting', 0),
(101, 'abs_5.png', 'wrtwrt', 'retwre', 'Reporting', 0),
(102, 'client-9.png', 'Common URL for real-time service tracking', 'Common URL for real-time service tracking', 'Fleet Management', 0),
(103, 'abs_3.png', 'System driven route management solution', '', 'Fleet Management', 0),
(104, 'bulb.png', 'Desired reports formats for reviews', 'Desired reports formats for reviews', 'Fleet Management', 0),
(105, 'abs_4.png', 'Enabling real-time fuel, tyre manage', '', 'Fleet Management', 0),
(106, 'driver behaviour.jpg', 'One of the biggest questions for any logistics companies, fleet owners is to ascertain how their vehicle is being handled while being in use. This absent factor till time remained a big factor in cost of vehicle management definitions. Acknowledging the problem to identify and define the driver behaviour and control human mishandling of the vehicle.\r\n\r\nITG offers its Telematics solutions through an integrated dashboard, hence getting and gaining access to all related parameters required for monitoring the driver behaviour on real time data basis, through an integrated URL and mobile applications.\r\n\r\nFactors like Over Speeding, Harsh Breaking, Acute Manoeuvring, Over Driving etc are now being easily monitored using our solution.\r\n\r\nOur offered platform brings real-time monitoring and management of driver behaviour further supported by asked for reports and derivatives as VAS to enable complete managements of the transport operations.', '', 'Driver Behavior', 0),
(107, 'tl_10 (1).png', 'System driven breach identification', '', 'Driver Behavior', 0),
(108, 'products-hdr-img2.jpg', 'afadfadf', '', 'FC10P', 0),
(109, 'products-hdr-img2.jpg', 'Advanced Asset Monitoring', '', 'AM10P', 0),
(112, 'gt06.png', 'It is an entry-level unit for fleet management and vehicle security applications and is equipped with a rechargeable backup battery (1000mAh) and GSM jamming detection algorithms for improved compliance with vehicle security applications. In addition, it is compatible with a variety of accessories which enable a wide range of applications such as fuel monitoring, temperature monitoring, identification and more.', 'FC10P', 'FC10P', 0),
(113, 'driver behaviour.jpg', 'Features', '', 'FC10P', 0),
(114, 'w1.png', 'Humidity (MultiSense TH)', '', 'FC10P', 0),
(115, 'w2.png', 'Barometric Pressure (Nano)', '', 'FC10P', 0),
(117, 'products-hdr-img3.jpg', 'Wireless Tracker with BLE Temperature and Multisense', 'Wireless Tracker with BLE Temperature and', 'WT10BLE', 0),
(118, 'gt06.png', 'he WT10BLE device provides real-time as well as offline monitoring of the location and condition of cargo, assets and goods, including specific alerts related to issues and delays, using its internal sensors and its capability to track a wide area of remote wireless sensors around it, providing the knowledge you need to manage your cargo and mobile assets effectively It ensures continuous recording, event-triggered logic and â€˜management by exceptionsâ€™ to eliminate supply chain mistakes, avoid delays or damages, and reduce insurance expenses. It also prevents theft, losses or misplacements by using proximity, tampering and location monitoring throughout the entire supply chain.', 'WT10BLE', 'WT10BLE', 0),
(119, 'w6.png', 'Features', '', 'WT10BLE', 0),
(120, 'w1.png', 'Humidity (MultiSense TH)', '', 'WT10BLE', 0),
(121, 'w2.png', 'Barometric Pressure (Nano)', '', 'WT10BLE', 0),
(122, 'w3.png', 'Sound (Nano)', '', 'WT10BLE', 0),
(123, 'w4.png', 'Tampering (Nano)', '', 'WT10BLE', 0),
(124, 'w5.png', 'Open/Close Door (MultiSense)', 'Open/Close Door (MultiSense)', 'WT10BLE', 0),
(125, 'w6.png', 'Impact/Free Fall', 'Impact/Free Fall', 'WT10BLE', 0),
(126, 'w7.png', 'Geo Fencing (Nano)', 'Geo Fencing (Nano)', 'WT10BLE', 0),
(127, 'w8.png', 'Movement', 'Movement', 'WT10BLE', 0),
(128, 'w9.png', 'Light', 'Light', 'WT10BLE', 0),
(129, 'client-3.png', 'Fleet management solution integrated with owner,driver and passanger interface', 'FLEET MANAGEMENT', 'Taxi and Cabs', 0),
(143, '', 'As an epitome of trust and stable solutions ensuring 99% uptime, our Fleet Management Solutions strives to excel with world class technology and expertise aspiring to bring together the largest network of state of the art GPS hardware, software and PAN India support services.', 'GPS Tracking We Make ', 'Home', 0),
(145, 'i1.png', 'Customised tracking solutions designed\r\nfor all industries.', 'INDUSTRY SPECIFIED TELEMATICS', 'Home', 0),
(147, 'i2.png', 'A smart monitoring platform to read\r\nand hear all GPS devices.', 'COMMON TRACKING PLATFORM', 'Home', 0),
(149, 'i3.png', 'We offer Software as a service (SAAS)\r\nfor all industries.', 'SOFTWARE AS A SERVICE', 'Home', 0),
(151, 'i4.png', 'Responsible and active PAN India\r\nfield services 24x7, 365 days.', 'FIELD SERVICE NETWORK', 'Home', 0),
(153, 'Our-Customer.jpg', '', 'OUR CUSTOMERS', 'Customers', 0),
(155, 'client-1a.jpg', '', '', 'Customers', 0),
(156, 'client-2a.jpg', '', '', 'Customers', 0),
(157, 'client-3a.jpg', '', '', 'Customers', 0),
(158, 'client-4a.jpg', '', '', 'Customers', 0),
(159, 'client-1.png', '', '', 'Customers', 0),
(160, 'client-6a.jpg', '', '', 'Customers', 0),
(161, 'client-7a.jpg', '', '', 'Customers', 0),
(162, 'client-8a.jpg', '', '', 'Customers', 0),
(163, 'client-9a.jpg', '', '', 'Customers', 0),
(164, 'client-10a.jpg', '', '', 'Customers', 0),
(165, 'client-11a.jpg', '', '', 'Customers', 0),
(166, 'client-12a.jpg', '', '', 'Customers', 0),
(181, 'client-3a.jpg', 'Enabling real-time speed and cruise controls based on GPS data.', 'SPEED CONTROLS', 'Taxi and Cabs', 0),
(185, 'abs_1.png', 'VAS integration with RFID, Camera, Biometric, Aligned Sensors.', 'VALUE ADDED SENSORS', 'Taxi and Cabs', 0),
(188, 'key-point.png', 'Fuel Monitoring', 'Fuel Monitoring', 'Taxi and Cabs', 0),
(189, 'client-3.png', 'RFID', 'RFID', 'Taxi and Cabs', 0),
(190, 'client-3a.jpg', 'Camera (MDVR)', 'Camera (MDVR)', 'Taxi and Cabs', 0),
(191, 'client-3a.jpg', 'Driver Behaviour', 'Driver Behaviour', 'Taxi and Cabs', 0),
(192, 'client-3.png', 'Geo - Fence', 'Geo - Fence', 'Taxi and Cabs', 0),
(193, 'client-3a.jpg', 'Panic Button', 'Panic Button', 'Taxi and Cabs', 0),
(194, 'client-2a.jpg', 'Overspeed Control', 'Overspeed Control', 'Taxi and Cabs', 0),
(195, 'bulb.png', 'End to End Taxi and Cabs business management solution supporting Owners, Drivers with Passenger interface.', 'SOLUTION', 'Taxi and Cabs', 0),
(196, 'client-6.png', 'Check out our telematics solutions meeting all the required parameters.', 'Telematics for Taxi and Cabs', 'Taxi and Cabs', 0),
(197, 'hardware.png', 'Our G-Trac TC10P integrated with OBD & I/O sensors can provide telematics solution for your cars & cabs tracking.', 'Hardware', 'Taxi and Cabs', 0),
(198, 'special-solution.png', 'Tours and Travel', 'Our special solutions', 'Taxi and Cabs', 0),
(199, 'client-4.png', 'Rent a Car', '', 'Taxi and Cabs', 0),
(200, 'client-3a.jpg', 'Call Center', '', 'Taxi and Cabs', 0),
(201, 'client-3a.jpg', 'Car on Self Drive', '', 'Taxi and Cabs', 0),
(202, 'abs_2.png', 'Check running hours and hand movement of your JCB.', 'JCB MACHINES', 'Heavy Machine', 0),
(203, 'bulb.png', 'Check out rotation movement clockwise - anti clockwise.', 'CONCRETE MIXERS', 'Heavy Machine', 0),
(204, 'client-3a.jpg', 'Check running hours against ignition hours.', 'HDD MACHINES', 'Heavy Machine', 0),
(205, 'key-point.png', 'Running Hours', '', 'Heavy Machine', 0),
(206, 'client-3.png', 'Precise Distance', '', 'Heavy Machine', 0),
(207, 'client-3a.jpg', 'Integrated Sensors', '', 'Heavy Machine', 0),
(208, 'client-3a.jpg', 'Fuel Consumption', '', 'Heavy Machine', 0),
(209, 'client-3.png', 'Unauthorized Usage', '', 'Heavy Machine', 0),
(210, 'client-3.png', 'Industrial Grade', '', 'Heavy Machine', 0),
(211, 'client-3a.jpg', 'Drum Rotation', '', 'Heavy Machine', 0),
(212, 'bulb.png', 'Check out our telematics solutions for tracking and monitoring of heavy machinery.', 'SOLUTION', 'Heavy Machine', 0),
(213, '', 'Our G-Trac HM10P integrated with I/O sensors can provide telematics solution for machine to machine tracking.', 'Machine to Machine Monitoring Solutions', 'Heavy Machine', 0),
(214, 'hardware.png', 'Our G-Trac HM10P integrated with I/O sensors can provide telematics solution for machine to machine tracking.', 'Hardware', 'Heavy Machine', 0),
(215, 'special-solution.png', 'JCB Machine', 'Our special solutions', 'Heavy Machine', 0),
(216, 'client-3a.jpg', 'Concrete Mixers', '', 'Heavy Machine', 0),
(217, 'bulb.png', 'HDD Machines', '', 'Heavy Machine', 0),
(218, 'client-3a.jpg', 'Power Generators', '', 'Heavy Machine', 0),
(219, 'client-3a.jpg', 'edfadfadfa', '', 'Heavy Machine', 0),
(220, 'client-3.png', 'System driven reporting mechanism', '', 'Driver Behavior', 0),
(221, 'client-3a.jpg', 'Remote accessibility and control', '', 'Driver Behavior', 0),
(222, 'client-3a.jpg', 'Predictive analysis forecasting', '', 'Driver Behavior', 0),
(223, '', 'Features', 'Features', 'MT10P', 0),
(224, 'm1.png', 'Door status detection', 'Door status detection', 'MT10P', 0),
(225, 'm2.png', 'SOS emergency call', 'SOS emergency call', 'MT10P', 0),
(226, 'm3.png', 'wo-way communication', 'wo-way communication', 'MT10P', 0),
(227, 'm6.png', 'Multiple analog & digital I/O', 'Multiple analog & digital I/O', 'MT10P', 0),
(228, 'm4.png', 'Multiple alarms', 'Multiple alarms', 'MT10P', 0),
(229, 'm5.png', 'Real-time GPS+AGPS tracking\r\n(Advanced)', 'Real-time GPS+AGPS tracking\r\n(Advanced)', 'MT10P', 0),
(230, 'client-3.png', '4G live camera SD recording of CCTV footage is possible with our MDVR.', 'LIVE TRACKING', 'School and Bus', 0),
(231, 'client-2a.jpg', 'Now you can get an alert whenever your child enters or exits from the school/bus.', 'ONBOARD', 'School and Bus', 0),
(232, 'client-2a.jpg', '4G live camera SD recording of CCTV footage is possible with our MDVR.', 'MDVR (CAMERA)', 'School and Bus', 0),
(233, 'solution-image.jpg', 'Major challenges for any Supply Chain Management operations today are real time based access and controls over the movement and usage data of the identified asset. G-Trac offers a reliable and proven Asset Tracking solution, enabling real time control and monitoring of its Productivity, Accuracy, Compliance and Accountability of the identified asset.', 'OUR SOLUTION', 'Asset Tracking', 0),
(234, 'Asset-tracking.jpg', '', 'ASSETS\r\nTRACKING', 'Asset Tracking', 0),
(235, 'client-2.png', 'Use remote digital locking/unlocking to keep assets safer.', 'LOCKING/UNLOCKING', 'Asset Tracking', 0),
(236, 'client-1a.jpg', 'Over the air remote connection to hardware.\r\nPrevious\r\n', 'OTA REMOTE CONNECTION', 'Asset Tracking', 0),
(237, 'client-2.png', 'Estimated time of departure and time of arrival.\r\nPrevious\r\n', 'FLEXIBLE SLEEP MECHANISM', 'Asset Tracking', 0),
(238, 'key-point.png', 'Real time Location', '', 'Asset Tracking', 0),
(239, 'client-2.png', 'ETD/ETD', '', 'Asset Tracking', 0),
(240, 'client-2.png', 'Smart Charging', '', 'Asset Tracking', 0),
(241, 'client-2.png', 'Alerts', 'Alerts', 'Asset Tracking', 0),
(242, 'client-2.png', 'Geo - Fence', '', 'Asset Tracking', 0),
(243, 'client-2a.jpg', 'Locking/Unlocking', '', 'Asset Tracking', 0),
(244, 'client-2.png', 'OTA Connectivity', '', 'Asset Tracking', 0),
(245, 'bulb.png', 'Providing assets tracking solution including transocean monitoring using RFID, GPS based technology.', 'SOLUTION', 'Asset Tracking', 0),
(246, 'client-2.png', 'Delays, Dynamic ETA, Journey Progress, Toll, are few of our smart customised reports.', 'Now the Entire Fleet Operations on Your Finger Tips.', 'Asset Tracking', 0),
(247, 'hardware.png', 'Our G-Trac AT10P with inbuilt 10000mAh battery can provide telematics solution for your assets.', 'Hardware', 'Asset Tracking', 0),
(248, 'special-solution.png', 'Wireless Device', 'Our special solutions', 'Asset Tracking', 0),
(249, 'client-2.png', 'Easy to Handle', '', 'Asset Tracking', 0),
(250, 'client-2a.jpg', 'Extended Battery Life', '', 'Asset Tracking', 0),
(251, 'client-2a.jpg', 'Fit to All', '', 'Asset Tracking', 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menuid` int(11) NOT NULL,
  `menuname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menuid`, `menuname`) VALUES
(1, 'Home'),
(2, 'About us'),
(3, 'Solutions'),
(4, 'Benefits'),
(5, 'Products'),
(6, 'Customers');

-- --------------------------------------------------------

--
-- Table structure for table `solutions`
--

CREATE TABLE `solutions` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `pdescription` longtext NOT NULL,
  `heading` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE `submenu` (
  `menuid` int(11) NOT NULL,
  `menuname` varchar(255) NOT NULL,
  `submenu` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`menuid`, `menuname`, `submenu`) VALUES
(3, 'Solutions', 'Taxi and Cabs'),
(3, 'Solutions', 'Heavy Machine'),
(4, 'Benefits', 'Fleet Management'),
(4, 'Benefits', 'Driver Behavior'),
(5, 'Products', 'WT10BLE'),
(5, 'Products', 'MT10P'),
(3, 'Solutions', 'School and Bus'),
(4, 'Benefits', 'Reporting'),
(3, 'Solutions', 'Asset Tracking'),
(0, '', ''),
(3, 'Solutions', 'Fuel Monitoring'),
(5, 'Products', 'FC10P'),
(5, 'Products', 'AM10P');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `name`) VALUES
(2, 'admin', 'admin', 'admin'),
(3, 'user', 'user', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `benefit`
--
ALTER TABLE `benefit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clientlogos`
--
ALTER TABLE `clientlogos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `imageupload`
--
ALTER TABLE `imageupload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `benefit`
--
ALTER TABLE `benefit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `clientlogos`
--
ALTER TABLE `clientlogos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `imageupload`
--
ALTER TABLE `imageupload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=252;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
