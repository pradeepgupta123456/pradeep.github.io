<?php
session_start();
error_reporting(0);
include "admin/config.php";
include "header.php";

if(isset($_POST['save'])) { // if save button on the form is clicked
  $imgid=intval($_GET['imageid']);
echo $imgid;
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  $pradeep = $_SESSION["abc"];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading, pagename) VALUES ('$imagename', '$PageDes', '$Heading', '$pradeep')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>

<style> 
.descritiopnclassposabsolution{
  font-size: 1.25rem;
}
.Updatedutton{
  display:none;
}
.carousel-control-prev-icon {
    background-image: url(media/lefticon.png);
}
.carousel-control-next-icon {
    background-image: url(media/righticon.png)
    
}
.dynamicsliderauto{
  float: left;
    width: 41%;
    margin-top: -1300px;
    margin-left: 55px;
}
.carousel-item.active,
.carousel-item-next,
.carousel-item-prev{
    display:block;
}
.maindiv h1{
  font-size:22px;
}
.maindiv{
  float: left;
  width: 100%;
}
.solution .hedimg:nth-child(2) img{
  width:100%;
  height:398px;
} 

.leftmenubaradmin{
  display:none;
}

.productsheading{
  position:absolute;
  font-size: 56px;
    font-weight: bold;
    text-align: center;
    margin-top: 71px;
    z-index: 999999;
    width: 100%;
  
}
.bold-text {
    font-weight: 600;
}
.spe_list {
    display: flex;
    flex-wrap: wrap;
    margin: 22px 0;
}
.margineand {
    flex: 1 50%;
    margin-bottom: 15px;
    border-bottom: 1px solid #fbfafa;
    padding-bottom: 5px;
}
section {
    display: block;
}
.por-header {
    background: #eae8e8;
    padding: 15px;
    text-align: left;
    color: #000;
    font-weight: bold;
    width: 100%;
    margin-bottom: 40px;
    font-size: 25px;
    border-radius: 5px;
}
.headclass:nth-child(3) {
  font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 100%;
    FLOAT: LEFT;
    height: 409px;
    position: absolute;
    top: 172px;
    text-align: center;
}

.headclass:nth-child(7) {
  margin-left: 10%;
    WIDTH: 146PX;
    FLOAT: LEFT;
    margin-top: 78px;
    margin-bottom: 200px;
    margin-right: 350px;
}
.headclass:nth-child(7) h1 {
  font-size: 68px;
    font-weight: bold;
|}
.headclass:nth-child(11) {
  margin-left: 6%;
    font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 47%;
    FLOAT: LEFT;
    display:none;
}
.headclass:nth-child(19) {
  margin-left: 6%;
    font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 47%;
    FLOAT: LEFT;
    display:none;
}
.maindiv2 h1 {
  font-size:22px;
}
.headclass:nth-child(11) h1 {
  font-size:30px;
}
.headclass:nth-child(15) {
  margin-left: 6%;
    font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 47%;
    FLOAT: LEFT;
    display:none;
}
.maindiv1 h1 {
  font-size:22px;
}
.headclass:nth-child(43) {
  margin-left: -2.4%;
    font-weight: 600;
    WIDTH: 27%;
    FLOAT: LEFT;
    text-align: left;
    margin-bottom: 24px;
}
.headclass:nth-child(47) {
    font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 100%;
    FLOAT: LEFT;
    text-align:center;
    margin-top: 21px;
}
.headclass:nth-child(47) h1 {
  color: rgb(242, 151, 54);
}

.headclass:nth-child(51) {
  font-size: 1.5vw;
    font-weight: 600;
    WIDTH: 25%;
    FLOAT: right;
    text-align: right;
    position: absolute;
    top: 1136px;
    right: 183px;
}
.headclass:nth-child(51) h1 {
  font-size: 1.5rem;
}
.headclass:nth-child(55) {
    WIDTH: 100%;
    FLOAT: LEFT;
    text-align: left;
    margin-top: 0px;
    text-align: center;
    padding-left: 100px;
    
}
.headclass:nth-child(55) h1{
  color: rgb(242, 151, 54);
    font-size: 3.6rem;
    font-family: 'Oswald', sans-serif;
    font-weight: 900;
}
.headclass:nth-child(59) {
  WIDTH: 50%;
    FLOAT: LEFT;
    margin-top: -535px;
    padding-left: 209px;    
}
.headclass:nth-child(63) {
  WIDTH: 50%;
    FLOAT: right;
    margin-top: -403px;
    padding-left: 88px;
}
.headclass:nth-child(63) h1 {
 font-size:40px
}
.descritiopnclassposabsolution:nth-child(4) {
  position: absolute;
    margin-top: -242px;
    margin-left: 7%;
    font-size: 1.5vw;
    font-weight: 600;
    margin-right: 7%;
}
.descritiopnclassposabsolution:nth-child(12) {
  margin-left: 6%;
    font-size: 1.5vw;
    font-weight: 600;
    width: 46%;
    float: left;
    display:none;
}
.descritiopnclassposabsolution:nth-child(20) {
  margin-left: 6%;
    font-size: 1.5vw;
    font-weight: 600;
    width: 46%;
    float: left;
    display:none;
}
.descritiopnclassposabsolution:nth-child(16) {
    font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 522px;
    margin-right: 349px;
    display: none;
}
.descritiopnclassposabsolution:nth-child(28) {
  font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: 36px;
    margin-top: 569px;
    margin-right: 349px;
}
.descritiopnclassposabsolution:nth-child(32) {
  font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 633px;
    margin-right: 423px;
}
.descritiopnclassposabsolution:nth-child(36) {
  font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 692px;
    margin-right: 423px;
}
.descritiopnclassposabsolution:nth-child(40) {
  margin-right: 349px;
    font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: 37px;
    margin-top: 753px;
}
.descritiopnclassposabsolution:nth-child(44) {
  float: left;
    width: 20%;
    margin-left: -40.5%;
    font-size: 19px;
    margin-top: 289px;
  }

  .descritiopnclassposabsolution:nth-child(48) {
    float: left;
    width: 100%;
    text-align: center;
    font-size: 19px;
    font-weight: 400;
    margin-top: -98px;
    margin-left: 72px;
  }
  .descritiopnclassposabsolution:nth-child(52) {
    width: 26%;
    text-align: left;
    position: absolute;
    z-index: 8;
    top: 1188px;
    font-size: 1.6rem;
    right: 24px;
  }
  .descritiopnclassposabsolution:nth-child(56) {
    width: 100%;
    text-align: center;
    float: left;
    font-size: 26px;
    font-weight: 400;
    margin-bottom: 100px;
  }
 
  .descritiopnclassposabsolution:nth-child(60) {
    width: 29%;
    margin-left: 16%;
    position: absolute;
    z-index: 8;
    top: 1851px;
    float: left;
    text-align: left;
    font-weight: 400;
    line-height: 41px;
    font-size: 1.5rem;
  }
  
  .descritiopnclassposabsolution:nth-child(64) {
    width: 33%;
    margin-left: 57.2%;
    text-align: center;
    position: absolute;
    z-index: 9999999999;
    top: 1973px;
    float: left;
    text-align: left;
    font-size: 24px;
    font-weight: 700;
    color: rgb(242, 151, 54);
    line-height: 50px;
  }
  .descritiopnclassposabsolution:nth-child(64):before {
    width: 8px;
    height: 8px;
    background-color: rgb(242, 151, 54);;
    content: "";
    margin-top: 24px;
    margin-right: 20px;
    float: left;
  }
  .descritiopnclassposabsolution:nth-child(68) {
    width: 33%;
    margin-left: 57.2%;
    position: absolute;
    z-index: 9999999999;
    top: 2025px;
    float: left;
    text-align: left;
    font-size: 24px;
    font-weight: 700;
    color: rgb(242, 151, 54);
    line-height: 50px;
  }
  .descritiopnclassposabsolution:nth-child(68):before {
    width: 8px;
    height: 8px;
    background-color: rgb(242, 151, 54);;
    content: "";
    margin-top: 24px;
    margin-right: 20px;
    float: left;
  }
  .descritiopnclassposabsolution:nth-child(72) {
    width: 33%;
    margin-left: 57.2%;
    position: absolute;
    z-index: 9999999999;
    top: 2076px;
    float: left;
    text-align: left;
    font-size: 24px;
    font-weight: 700;
    color: rgb(242, 151, 54);
    line-height: 50px;
  }
  .descritiopnclassposabsolution:nth-child(72):before {
    width: 8px;
    height: 8px;
    background-color: rgb(242, 151, 54);;
    content: "";
    margin-top: 24px;
    margin-right: 20px;
    float: left;
  }
  .descritiopnclassposabsolution:nth-child(76) {
    width: 33%;
    margin-left: 57.2%;
    position: absolute;
    z-index: 9999999999;
    top: 2128px;
    float: left;
    text-align: left;
    font-size: 24px;
    font-weight: 700;
    color: rgb(242, 151, 54);
    line-height: 50px;
  }
  .descritiopnclassposabsolution:nth-child(76):before {
    width: 8px;
    height: 8px;
    background-color: rgb(242, 151, 54);;
    content: "";
    margin-top: 24px;
    margin-right: 20px;
    float: left;
  }

.descritiopnclassposabsolution:nth-child(20) {
    font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: -37px;
    margin-top: 579px;
    margin-right: 349px;
}
.descritiopnclassposabsolution:nth-child(24) {
  font-size: 1.3vw;
    font-weight: 400;
    width: 22%;
    float: left;
    position: absolute;
    right: 37px;
    margin-top: 505px;
    margin-right: 349px;
}

.hedimg:nth-child(6) {
  width: 50%;
    float: left;
    padding: 14px;
    margin-left: 32px;
}
.hedimg:nth-child(10) {
display:none;
}

.hedimg:nth-child(14) {
  display:none;
}
.hedimg:nth-child(18) {
display:none;
}
.hedimg:nth-child(22) {
float:left;
margin-left: 626px;
margin-top: -57px;
}
.hedimg:nth-child(26) {
display:none;
}
.hedimg:nth-child(30) {
display:none;
}
.hedimg:nth-child(34) {
display:none;
}
.hedimg:nth-child(38) {
display:none;
}
.hedimg:nth-child(42) {
 
    display:none;
  }
  .hedimg:nth-child(50) {
    float: right;
    margin-right: -22%;
    margin-top: -499px;
    width: 45%;
  }
  .hedimg:nth-child(54) {
    display:none;
  }
  .hedimg:nth-child(58) {
    float: left;
    margin-left: 75px;
  }
 
  .hedimg:nth-child(66) {
  display:none;
  }
  .hedimg:nth-child(70) {
  display:none;
  }

  .hedimg:nth-child(74) {
  display:none;
  }


  .headclass:nth-child(43) h1{
    font-size:22px;
    font-weight:bold;
    text-align:center;
  }
  .hedimg:nth-child(46) {
    display:none;

  }

.descritiopnclassproduct:nth-child(7) {
  width: 50%;
    float: left;
    padding: 49px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
}
.hedimg:nth-child(11) {
 display:none
}
.descritiopnclassproduct:nth-child(10) {
  width: 100%;
    float: left;
    padding: 68px 80px;
    font-weight: 600;
    font-size: 1.2rem;
    line-height: 1.65rem;
    text-align: justify;
    background-color: rgba(0, 0, 0, 0.56);
    color:#fff;
    font-size:22px;
    text-align:center;
}
.descritiopnclassproduct:nth-child(10):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;78/    *63-+21
}
.hedimg:nth-child(12) {
 display:none
}
.descritiopnclassproduct:nth-child(13) {
 background: #eae8e8;
    padding: 15px;
    text-align: left;
    color: #000;
    font-weight: bold;
    width: 91%;
    font-size: 25px;
    border-radius: 5px;
    float: left;
    margin-left: 62px;
}


.descritiopnclassproduct:nth-child(17) {
  float: left;
  margin-top:36px
}
.descritiopnclassproduct:nth-child(16):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.hedimg:nth-child(15) {
  width:100px;
  float:left;

}
.hedimg:nth-child(19) {
  width:100px;
  float:left;

}
.hedimg:nth-child(23) {
  width:100px;
  float:left;
}
.hedimg:nth-child(27) {
  width:100px;
  float:left;
}
.hedimg:nth-child(31) {
  width:100px;
  float:left;
}
.hedimg:nth-child(35) {
  width:100px;
  float:left;
}
.hedimg:nth-child(39) {
  width:100px;
  float:left;
}
.hedimg:nth-child(43) {
  width:100px;
  float:left;
}
.hedimg:nth-child(47) {
  width:100px;
  float:left;
}


.descritiopnclassproduct:nth-child(21) {
width: 17%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(25) {
width: 11%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(29) {
width: 11%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(33) {
width: 19%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(37) {
width: 19%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(41) {
width: 15%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(45) {
width: 15%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}
.descritiopnclassproduct:nth-child(49) {
width: 15%;
    float: left;
    padding: 31px 0px;
    font-size: 1.2rem;
    line-height: 1.65rem;
    color: #000;
    font-size: 18px;
    text-align: left;
    margin-top: 2px;
}



.descritiopnclassproduct:nth-child(19):hover{
  background-color:#fff;
  transition: all ease 0.7s;
    position: relative;
}
.Updatedutton:nth-child(5) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: 133px;
    right: 0px;
}
.Updatedutton:nth-child(9) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: left;
    margin-left: -3%;
    float: left;
    margin-top: 262px;
}
.Updatedutton:nth-child(13) {
  width: 5%;
    font-size: 18px;
    text-align: left;
    margin-left: -9%;
    float: left;
    margin-top: 55px;
    display:none;
}
.Updatedutton:nth-child(30) {
 width: 10%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(34) {
 width: 10%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(38) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(42) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(46) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}
.Updatedutton:nth-child(50) {
 width: 4%;
    font-size: 18px;
    text-align: left;
    margin-left: 0%;
    float: left;
    margin-top: 30px;
    height: 100PX;
}


.Updatedutton:nth-child(11) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -548px;
    right: 0px;
}
.Updatedutton:nth-child(14) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -706px;
    right: 0px;
    display:none;
}
.Updatedutton:nth-child(17) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    float: left;
    margin-top: -54px;
    display:none;
}
.Updatedutton:nth-child(21) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    float: left;
    margin-top: 4px;
    position: relative;
    display:none;
}
.Updatedutton:nth-child(25) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    float: left;
    margin-top: -20px;
    position: relative;
}
.Updatedutton:nth-child(29) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 38px;
    position: relative;
}
.Updatedutton:nth-child(33) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 104px;
    position: relative;
}
.Updatedutton:nth-child(37) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 164px;
    position: relative;
}
.Updatedutton:nth-child(41) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 224px;
    position: relative;
}

.Updatedutton:nth-child(45) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -27.5%;
    float: left;
    margin-top: 286px;
    position: relative;
}
.Updatedutton:nth-child(49) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-right: 34.5%;
    float: right;
    margin-top: -98px;
}
.Updatedutton:nth-child(53) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-top: 854px;
    position: absolute;
    right: 5px;
}
.Updatedutton:nth-child(57) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    float: right;
    margin-top: 1056px;
    position: absolute;
    right: 5px;
}
.Updatedutton:nth-child(61) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 45%;
    margin-top: 1609px;
    position: absolute;
}
.Updatedutton:nth-child(65) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
   
    margin-top: -309px;
    position: absolute;
    right: 84px;
}
.Updatedutton:nth-child(69) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-right: 6%;
    float: right;
    margin-top: -265px;
}
.Updatedutton:nth-child(73) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-right: 6%;
    float: right;
    margin-top: -221px;
}
.Updatedutton:nth-child(77) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-right: 6%;
    float: right;
    margin-top: -166px;
}

.Updatedutton:nth-child(30) {
  width: 3%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: -3%;
    float: left;
    margin-top: 114px;
    position: relative;
}

.Updatedutton:nth-child(20) {
  position: absolute;
    width: 86%;
    font-size: 19.2px;
    font-weight: 700;
    text-align: right;
    margin-left: 0%;
    bottom: -1026px;
    right: 0px;
}
</style>
 <div class="solution">
 
 
  <form class="form-horizontal " name="insertproduct" method="post" enctype="multipart/form-data">
    
    

    <div class="control-group"> 
    <button id="hide" class="float-right">Hide</button>
      <label class="control-label" for="basicinput">Upload Image</label>
      <div class="controls">
        <input type="file" name="imagename" id="imagename" value="" class="span8 tip" required>
      </div>
      <textarea class="headingname" name="allheading" placeholder="heading"></textarea>
      <textarea id="edit" name="firstpage" placeholder="Description"></textarea>
      <div class="col-md-6">
       
        <a class="pagename "><?php
     
      if(isset($_POST['submit1'])) {
    
        $pradeep = $_POST['submit1'];
       
       echo "$pradeep";
       
       $_SESSION["abc"] = $pradeep;
    
      }
      ?> </a>
  
              
    </div>
    </div>
    <div class="form-group row pt-3">
      <div class="col-12">
        <button type="submit" class="btn btn-success" name="save">
          <i class="fa fa-plus "></i> Upload
        </button>
      </div>
    </div>
  </form>

  <?php 
     
     
     $sql = "SELECT * from imageupload where pagename='$pradeep' LIMIT 19";
     $query = $dbh -> prepare($sql);
     $query->execute();
     $results=$query->fetchAll(PDO::FETCH_OBJ);
     $cnt=1;
     if($query->rowCount() > 0)
     {
       foreach($results as $result)
       {
         ?>	
       
     
           <div class="hedimg">
             <img class="img-fluid" src="media/<?php  echo $result->filename?>" alt="Image"/>
           </div>
           <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
           <div class="descritiopnclassposabsolution"><?php echo ($result->pdescription) ?> </div>
           <div class="Updatedutton">
             <a href="update.php?imageid=<?php echo ($result->id) ?>" class="btn "><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
       </div>
      
         <?php
         $cnt=$cnt+1;
       }
     } ?>

</div>
<div class="dynamicsliderauto">
    <div id="carouselContent" class="carousel slide " data-ride="carousel">
        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active text-center p-5 ">
            <div class="maindiv"></div>
            <div class="maindivdescription"></div>
            <div class="maindivupdatebutton"></div>
            
            </div>
            <div class="carousel-item text-center p-5">
                
            <div class="maindiv1"></div>
            <div class="maindivdescription1"></div>
            <div class="maindivupdatebutton1"></div>
            </div>
            <div class="carousel-item text-center p-5">
                
            <div class="maindiv2"></div>
            <div class="maindivdescription2"></div>
            <div class="maindivupdatebutton1"></div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselContent" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselContent" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>

  
   
</section>
   
       
</div> 

<script>
      $('.headclass:nth-child(11)').clone().appendTo('.maindiv');
      $('.descritiopnclassposabsolution:nth-child(12)').clone().appendTo('.maindivdescription');
      $('.Updatedutton:nth-child(13)').clone().appendTo('.maindivupdatebutton');
      
      $('.headclass:nth-child(15)').clone().appendTo('.maindiv1');
      $('.descritiopnclassposabsolution:nth-child(16)').clone().appendTo('.maindivdescription1');
      $('.Updatedutton:nth-child(17)').clone().appendTo('.maindivupdatebutton1');

      $('.headclass:nth-child(19)').clone().appendTo('.maindiv2');
      $('.descritiopnclassposabsolution:nth-child(20)').clone().appendTo('.maindivdescription2');
      $('.Updatedutton:nth-child(17)').clone().appendTo('.maindivupdatebutton2');
     
   </script>
    
      <?php
     include "footer.php";
      ?>






