<?php
session_start();
error_reporting(0);
include "admin/config.php";
include "header.php";

if(isset($_POST['save'])) { // if save button on the form is clicked
  $imagename=$_FILES["imagename"]["name"];
  $PageDes = $_POST['firstpage'];
  $Heading = $_POST['allheading'];
  $pradeep = $_SESSION["abc"];
  move_uploaded_file($_FILES["imagename"]["tmp_name"],"media/".$_FILES["imagename"]["name"]);
  $sql = "INSERT INTO imageupload (filename, pdescription, heading, pagename) VALUES ('$imagename', '$PageDes', '$Heading', '$pradeep')";
  if (mysqli_query($conn, $sql)) 
  {
    echo "<script>alert('Image uploaded successfully');</script>";
  }
  else {
    echo "<script>alert('Failed to upload image.');</script>";
  }
}
?>
<style>
  .product_client_contner img{
    margin-bottom:40px;
  }
    .customerfirst {
        position: absolute;
    bottom: 148px;
    right: 0;

    }
.form-horizontal{
  display:none;
}

</style>


 <div class="aboutusmain">

 
  <form class="form-horizontal " name="insertproduct" method="post" enctype="multipart/form-data">
    
    

    <div class="control-group"> 

<button id="hide" class="float-right">Hide</button>
      <label class="control-label" for="basicinput">Upload Image</label>
      <div class="controls">
        <input type="file" name="imagename" id="imagename" value="" class="span8 tip" required>
      </div>    
      <textarea class="headingname" name="allheading" placeholder="head text here"></textarea>
      <textarea id="edit" name="firstpage" placeholder="Desc text here"></textarea>
      <div class="col-md-6">
       
        <a class="pagename"><?php
     
      if(isset($_POST['submit1'])) {
    
        $pradeep = $_POST['submit1'];
       
       echo "$pradeep";
       
       $_SESSION["abc"] = $pradeep;
    
      }
      ?> </a>
  
              
    </div>
    </div>
    <div class="form-group row pt-3">
      <div class="col-12">
        <button type="submit" class="btn btn-success" name="save">
          <i class="fa fa-plus "></i> Upload
        </button>
      </div>
    </div>
  </form>

  

      <?php 
      $sql = "SELECT * from imageupload where id='153'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            <div class="headclass"><h1><?php echo ($result->heading) ?></h1> </div>
            <div class="positionabsolutefirst"><?php echo ($result->pdescription) ?> </div>
         
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      
      <section class="product_client">

<div class="container">

<div class="product_client_contner row">
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='155'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
       
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
      </div>
      <div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='156'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
      
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='157'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
          
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='158'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
         
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='159'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
          
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='160'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
           
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='161'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
         
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='162'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
         
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='163'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
           
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='164'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
         
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='165'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
         
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
<div class="col-md-2">
<?php 
      $sql = "SELECT * from imageupload where id='166'";
      $query = $dbh -> prepare($sql);
      $query->execute();
      $results=$query->fetchAll(PDO::FETCH_OBJ);
      $cnt=1;
      if($query->rowCount() > 0)
      {
        foreach($results as $result)
        {
          ?>	
        
         
            <div class="hedimg">
              <img class="img-fluid" src="media/<?php  echo $result->filename;?>" alt="Image"/>
            </div>
            
           
        
          <?php
          $cnt=$cnt+1;
        }
      } ?>
</div>
</div>

</div>

</section>   
</div> 


     
      <?php
     include "footer.php";
      ?>






